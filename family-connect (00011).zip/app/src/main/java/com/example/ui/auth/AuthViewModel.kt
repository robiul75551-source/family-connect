package com.example.ui.auth

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.R
import com.example.data.model.PrivateUserInfo
import com.example.data.model.UserProfile
import com.example.data.repository.UserRepository
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.FirebaseException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.auth.auth
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

object BangladeshPhoneUtils {
  /**
   * Normalizes and validates a Bangladesh mobile phone number.
   * Expected format in E.164: +8801XXXXXXXXX (10 digits starting with 1 after +880)
   */
  fun formatAndValidate(rawInput: String): Pair<Boolean, String> {
    val trimmed = rawInput.trim()
    val digitsOnly = trimmed.filter { it.isDigit() }

    val normalizedNumber = when {
      trimmed.startsWith("+880") -> {
        val after880 = trimmed.removePrefix("+880").trim().filter { it.isDigit() }
        val cleanAfter = if (after880.startsWith("0")) after880.removePrefix("0") else after880
        "+880$cleanAfter"
      }
      trimmed.startsWith("880") -> {
        val after880 = trimmed.removePrefix("880").trim().filter { it.isDigit() }
        val cleanAfter = if (after880.startsWith("0")) after880.removePrefix("0") else after880
        "+880$cleanAfter"
      }
      digitsOnly.startsWith("01") -> {
        "+880${digitsOnly.removePrefix("0")}"
      }
      digitsOnly.startsWith("1") -> {
        "+880$digitsOnly"
      }
      else -> {
        "+880$digitsOnly"
      }
    }

    // Bangladesh mobile numbers have +880 followed by 10 digits starting with 1
    // (e.g. +8801712345678, operators: 013, 014, 015, 016, 017, 018, 019 or test numbers)
    val numberRegex = Regex("^\\+8801\\d{9}$")
    val isValid = numberRegex.matches(normalizedNumber)

    return Pair(isValid, normalizedNumber)
  }
}

sealed interface AuthUiState {
  object Idle : AuthUiState
  object Loading : AuthUiState
  data class Error(val message: String) : AuthUiState
}

class AuthViewModel(private val userRepository: UserRepository) : ViewModel() {

  private val _uiState = MutableStateFlow<AuthUiState>(AuthUiState.Idle)
  val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

  private val _currentUser = MutableStateFlow(Firebase.auth.currentUser)
  val currentUser = _currentUser.asStateFlow()

  private val _userProfile = MutableStateFlow<UserProfile?>(null)
  val userProfile = _userProfile.asStateFlow()

  private val _privateInfo = MutableStateFlow<PrivateUserInfo?>(null)
  val privateInfo = _privateInfo.asStateFlow()

  private val _isSessionUnlocked = MutableStateFlow(false)
  val isSessionUnlocked = _isSessionUnlocked.asStateFlow()

  // Phone Authentication State
  private val _isOtpSent = MutableStateFlow(false)
  val isOtpSent: StateFlow<Boolean> = _isOtpSent.asStateFlow()

  private val _isSendingOtp = MutableStateFlow(false)
  val isSendingOtp: StateFlow<Boolean> = _isSendingOtp.asStateFlow()

  private val _isVerifyingOtp = MutableStateFlow(false)
  val isVerifyingOtp: StateFlow<Boolean> = _isVerifyingOtp.asStateFlow()

  private val _resendCountdownSeconds = MutableStateFlow(0)
  val resendCountdownSeconds: StateFlow<Int> = _resendCountdownSeconds.asStateFlow()

  private val _phoneAuthMessage = MutableStateFlow<String?>(null)
  val phoneAuthMessage: StateFlow<String?> = _phoneAuthMessage.asStateFlow()

  private val _phoneAuthError = MutableStateFlow<String?>(null)
  val phoneAuthError: StateFlow<String?> = _phoneAuthError.asStateFlow()

  private var verificationId: String? = null
  private var forceResendingToken: PhoneAuthProvider.ForceResendingToken? = null
  private var countdownJob: Job? = null
  private var lastFormattedPhoneNumber: String = ""

  private val authStateListener = FirebaseAuth.AuthStateListener { auth ->
    _currentUser.value = auth.currentUser
    if (auth.currentUser != null) {
      loadUserData(auth.currentUser!!.uid)
    } else {
      _userProfile.value = null
      _privateInfo.value = null
      _isSessionUnlocked.value = false
    }
  }

  init {
    Firebase.auth.addAuthStateListener(authStateListener)
    _currentUser.value?.uid?.let { loadUserData(it) }
  }

  override fun onCleared() {
    super.onCleared()
    countdownJob?.cancel()
    Firebase.auth.removeAuthStateListener(authStateListener)
  }

  fun unlockSession() {
    _isSessionUnlocked.value = true
  }

  fun lockSession() {
    _isSessionUnlocked.value = false
  }

  private fun loadUserData(uid: String) {
    viewModelScope.launch {
      try {
        userRepository.observeUserProfile(uid).collect { profile ->
          _userProfile.value = profile
        }
      } catch (e: Exception) {
        Log.e("AuthViewModel", "Failed to observe profile", e)
      }
    }
    viewModelScope.launch {
      try {
        userRepository.observePrivateInfo(uid).collect { info ->
          _privateInfo.value = info
          if (info == null || !info.appLockEnabled) {
            _isSessionUnlocked.value = true
          }
        }
      } catch (e: Exception) {
        Log.e("AuthViewModel", "Failed to observe private info", e)
      }
    }
  }

  fun signInWithGoogle(context: Context, onAuthSuccess: () -> Unit) {
    _uiState.value = AuthUiState.Loading
    val clientId = try {
      context.getString(R.string.default_web_client_id)
    } catch (e: Exception) {
      _uiState.value = AuthUiState.Error("Google Client ID configuration missing.")
      return
    }

    val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
    val request = GetCredentialRequest.Builder().addCredentialOption(signInOption).build()
    val credentialManager = CredentialManager.create(context)

    viewModelScope.launch {
      try {
        val result = credentialManager.getCredential(context as Activity, request)
        val credential = result.credential
        if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
          val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
          val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
          Firebase.auth.signInWithCredential(authCredential).await()
          _uiState.value = AuthUiState.Idle
          onAuthSuccess()
        } else {
          _uiState.value = AuthUiState.Error("Unsupported credential type returned.")
        }
      } catch (e: GetCredentialCancellationException) {
        Log.w("Auth", "Google Sign-In cancelled: ${e.message}", e)
        _uiState.value = AuthUiState.Idle
      } catch (e: Exception) {
        Log.e("Auth", "Google Sign-In failed", e)
        _uiState.value = AuthUiState.Error(e.localizedMessage ?: "Sign-in failed. Please retry.")
      }
    }
  }

  fun completeProfileSetup(
    username: String,
    displayName: String,
    avatarSeed: String,
    phone: String = "",
    email: String = "",
    onSuccess: () -> Unit
  ) {
    _uiState.value = AuthUiState.Loading
    viewModelScope.launch {
      val res = userRepository.registerUserProfile(
        username = username,
        displayName = displayName,
        avatarSeed = avatarSeed,
        phone = phone,
        email = email
      )
      if (res.isSuccess) {
        _uiState.value = AuthUiState.Idle
        _isSessionUnlocked.value = true
        onSuccess()
      } else {
        _uiState.value = AuthUiState.Error(res.exceptionOrNull()?.localizedMessage ?: "Failed to set up profile.")
      }
    }
  }

  fun sendPhoneVerificationCode(
    activity: Activity,
    rawPhoneNumber: String,
    onCodeSentSuccess: () -> Unit = {}
  ) {
    val (isValid, formattedNumber) = BangladeshPhoneUtils.formatAndValidate(rawPhoneNumber)
    if (!isValid) {
      _phoneAuthError.value = "Invalid Bangladesh phone number format. Please enter a 10-digit number (e.g., 1712 345678 or 01712 345678) with +880."
      _phoneAuthMessage.value = null
      return
    }

    lastFormattedPhoneNumber = formattedNumber
    _isSendingOtp.value = true
    _phoneAuthError.value = null
    _phoneAuthMessage.value = "Sending SMS verification code to $formattedNumber..."

    val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
      override fun onVerificationCompleted(credential: PhoneAuthCredential) {
        _isSendingOtp.value = false
        _phoneAuthMessage.value = "Instant verification completed by Google Play Services."
        signInWithPhoneCredential(credential)
      }

      override fun onVerificationFailed(e: FirebaseException) {
        _isSendingOtp.value = false
        Log.e("AuthViewModel", "Phone verification failed: ${e.message}", e)
        _phoneAuthError.value = mapFirebasePhoneException(e)
        _phoneAuthMessage.value = null
      }

      override fun onCodeSent(
        verificationId: String,
        token: PhoneAuthProvider.ForceResendingToken
      ) {
        _isSendingOtp.value = false
        this@AuthViewModel.verificationId = verificationId
        this@AuthViewModel.forceResendingToken = token
        _isOtpSent.value = true
        _phoneAuthError.value = null
        _phoneAuthMessage.value = "6-digit SMS verification code sent to $formattedNumber"
        startResendCooldownTimer()
        onCodeSentSuccess()
      }
    }

    val optionsBuilder = PhoneAuthOptions.newBuilder(Firebase.auth)
      .setPhoneNumber(formattedNumber)
      .setTimeout(60L, TimeUnit.SECONDS)
      .setActivity(activity)
      .setCallbacks(callbacks)

    forceResendingToken?.let { optionsBuilder.setForceResendingToken(it) }

    try {
      PhoneAuthProvider.verifyPhoneNumber(optionsBuilder.build())
    } catch (e: Exception) {
      _isSendingOtp.value = false
      Log.e("AuthViewModel", "Failed to invoke verifyPhoneNumber", e)
      _phoneAuthError.value = mapFirebasePhoneException(e)
      _phoneAuthMessage.value = null
    }
  }

  fun resendPhoneVerificationCode(activity: Activity) {
    if (_resendCountdownSeconds.value > 0) {
      _phoneAuthError.value = "Please wait ${_resendCountdownSeconds.value} seconds before requesting a new code."
      return
    }
    if (lastFormattedPhoneNumber.isBlank()) {
      _phoneAuthError.value = "Please enter your phone number first."
      return
    }
    sendPhoneVerificationCode(activity, lastFormattedPhoneNumber)
  }

  fun verifyPhoneCode(
    smsCode: String,
    onSuccess: () -> Unit = {}
  ) {
    val cleanCode = smsCode.trim()
    if (cleanCode.length != 6 || !cleanCode.all { it.isDigit() }) {
      _phoneAuthError.value = "Please enter the valid 6-digit verification code."
      return
    }

    val currentVerificationId = verificationId
    if (currentVerificationId.isNullOrBlank()) {
      _phoneAuthError.value = "Verification session expired. Please request a new code."
      return
    }

    _isVerifyingOtp.value = true
    _phoneAuthError.value = null
    _phoneAuthMessage.value = "Verifying code with Firebase Authentication..."

    val credential = PhoneAuthProvider.getCredential(currentVerificationId, cleanCode)
    signInWithPhoneCredential(credential, onSuccess)
  }

  fun signInWithPhoneCredential(
    credential: PhoneAuthCredential,
    onSuccess: () -> Unit = {}
  ) {
    viewModelScope.launch {
      try {
        _uiState.value = AuthUiState.Loading
        Firebase.auth.signInWithCredential(credential).await()
        _uiState.value = AuthUiState.Idle
        _isVerifyingOtp.value = false
        _phoneAuthMessage.value = "Phone verification successful."
        _phoneAuthError.value = null
        onSuccess()
      } catch (e: Exception) {
        _uiState.value = AuthUiState.Idle
        _isVerifyingOtp.value = false
        Log.e("AuthViewModel", "Phone sign in with credential failed", e)
        _phoneAuthError.value = mapFirebasePhoneException(e)
        _phoneAuthMessage.value = null
      }
    }
  }

  private fun startResendCooldownTimer(seconds: Int = 60) {
    countdownJob?.cancel()
    _resendCountdownSeconds.value = seconds
    countdownJob = viewModelScope.launch {
      for (remaining in (seconds - 1) downTo 0) {
        delay(1000L)
        _resendCountdownSeconds.value = remaining
      }
    }
  }

  fun resetPhoneAuthState() {
    _isOtpSent.value = false
    _isSendingOtp.value = false
    _isVerifyingOtp.value = false
    _phoneAuthError.value = null
    _phoneAuthMessage.value = null
    verificationId = null
    forceResendingToken = null
    countdownJob?.cancel()
    _resendCountdownSeconds.value = 0
  }

  private fun mapFirebasePhoneException(e: Exception): String {
    val message = e.message ?: ""
    return when {
      e is FirebaseAuthInvalidCredentialsException -> {
        if (message.contains("format", ignoreCase = true) || message.contains("phone", ignoreCase = true)) {
          "The phone number format is invalid for Bangladesh (+880). Example: +880 1712 345678."
        } else {
          "Invalid verification code. Please check the 6-digit SMS code and try again."
        }
      }
      e is FirebaseTooManyRequestsException -> {
        "Too many verification attempts. Please wait a few minutes before trying again or configure test numbers in Firebase Console."
      }
      message.contains("SMS region", ignoreCase = true) || message.contains("region", ignoreCase = true) -> {
        "SMS sending to Bangladesh (+880) is blocked by Firebase SMS Region Policy. Enable Bangladesh (+880) in Firebase Console > Authentication > Settings > SMS Region Policy."
      }
      message.contains("quota", ignoreCase = true) || message.contains("billing", ignoreCase = true) -> {
        "Daily SMS quota reached. In Firebase Console, enable Blaze plan or add test phone numbers under Authentication > Sign-in method > Phone."
      }
      message.contains("app not authorized", ignoreCase = true) || message.contains("recaptcha", ignoreCase = true) || message.contains("integrity", ignoreCase = true) -> {
        "App verification check failed. Ensure Google Play Services is available and SHA-1 certificate is added in Firebase Console."
      }
      message.contains("NETWORK", ignoreCase = true) -> {
        "Network error. Please check your internet connection and try again."
      }
      else -> {
        e.localizedMessage ?: "Phone authentication encountered an unexpected error. Please try again."
      }
    }
  }

  fun signOut(context: Context, onComplete: () -> Unit) {
    Firebase.auth.signOut()
    val credentialManager = CredentialManager.create(context)
    viewModelScope.launch {
      try {
        credentialManager.clearCredentialState(ClearCredentialStateRequest())
      } catch (e: Exception) {
        Log.e("Auth", "Failed to clear credential state", e)
      } finally {
        _isSessionUnlocked.value = false
        onComplete()
      }
    }
  }
}
