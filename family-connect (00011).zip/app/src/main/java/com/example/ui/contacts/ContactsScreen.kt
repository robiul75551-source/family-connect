package com.example.ui.contacts

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.BlockedContact
import com.example.data.model.UserContact
import com.example.data.model.UserProfile
import com.example.data.repository.UserRepository
import com.example.ui.chat.NewDirectChatDialog
import com.example.ui.common.UserAvatar
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContactsScreen(
  userRepository: UserRepository,
  onStartChatWithUser: (UserProfile) -> Unit,
  modifier: Modifier = Modifier
) {
  val scope = rememberCoroutineScope()
  var selectedTab by remember { mutableIntStateOf(0) } // 0: Contacts, 1: Blocked
  var contactsList by remember { mutableStateOf<List<UserContact>>(emptyList()) }
  var blockedList by remember { mutableStateOf<List<BlockedContact>>(emptyList()) }
  var isLoading by remember { mutableStateOf(true) }
  var showAddContactDialog by remember { mutableStateOf(false) }

  LaunchedEffect(Unit) {
    launch {
      try {
        userRepository.observeContacts().collect { list ->
          contactsList = list
          isLoading = false
        }
      } catch (e: Exception) {
        isLoading = false
      }
    }
    launch {
      try {
        userRepository.observeBlocked().collect { list ->
          blockedList = list
        }
      } catch (e: Exception) {}
    }
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Text("Contacts & Family", fontWeight = FontWeight.Bold)
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
      )
    },
    floatingActionButton = {
      if (selectedTab == 0) {
        FloatingActionButton(
          onClick = { showAddContactDialog = true },
          containerColor = MaterialTheme.colorScheme.primary,
          contentColor = MaterialTheme.colorScheme.onPrimary,
          shape = CircleShape,
          modifier = Modifier.testTag("add_contact_fab")
        ) {
          Icon(imageVector = Icons.Default.PersonAdd, contentDescription = "Add Contact")
        }
      }
    },
    modifier = modifier.testTag("contacts_screen")
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .background(MaterialTheme.colorScheme.background)
    ) {
      TabRow(
        selectedTabIndex = selectedTab,
        containerColor = MaterialTheme.colorScheme.surface,
        contentColor = MaterialTheme.colorScheme.primary
      ) {
        Tab(
          selected = selectedTab == 0,
          onClick = { selectedTab = 0 },
          text = { Text("Family Contacts (${contactsList.size})") }
        )
        Tab(
          selected = selectedTab == 1,
          onClick = { selectedTab = 1 },
          text = { Text("Blocked (${blockedList.size})") }
        )
      }

      if (isLoading) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
          CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
        }
      } else {
        if (selectedTab == 0) {
          if (contactsList.isEmpty()) {
            Box(
              modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
              contentAlignment = Alignment.Center
            ) {
              Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                  imageVector = Icons.Default.Security,
                  contentDescription = null,
                  tint = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.size(48.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                  text = "No saved contacts yet",
                  style = MaterialTheme.typography.titleMedium,
                  fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                  text = "Add your family members using their unique username to keep them easily accessible.",
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                  textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
              }
            }
          } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
              items(contactsList, key = { it.contactUserId }) { contact ->
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                      scope.launch {
                        val res = userRepository.findUserByUsername(contact.username)
                        res.getOrNull()?.let { onStartChatWithUser(it) }
                      }
                    }
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  UserAvatar(name = contact.displayName, seed = contact.contactUserId, size = 44.dp)
                  Spacer(modifier = Modifier.width(14.dp))
                  Column(modifier = Modifier.weight(1f)) {
                    Text(contact.displayName, fontWeight = FontWeight.SemiBold)
                    Text("@${contact.username}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                  }

                  IconButton(
                    onClick = {
                      scope.launch {
                        val res = userRepository.findUserByUsername(contact.username)
                        res.getOrNull()?.let { onStartChatWithUser(it) }
                      }
                    }
                  ) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.Chat, contentDescription = "Chat", tint = MaterialTheme.colorScheme.primary)
                  }

                  IconButton(
                    onClick = {
                      scope.launch {
                        userRepository.blockUser(contact.contactUserId, contact.username)
                        userRepository.removeContact(contact.contactUserId)
                      }
                    }
                  ) {
                    Icon(imageVector = Icons.Default.Block, contentDescription = "Block", tint = MaterialTheme.colorScheme.error)
                  }

                  IconButton(
                    onClick = {
                      scope.launch {
                        userRepository.removeContact(contact.contactUserId)
                      }
                    }
                  ) {
                    Icon(imageVector = Icons.Default.Delete, contentDescription = "Remove", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                  }
                }
                HorizontalDivider(
                  modifier = Modifier.padding(start = 72.dp),
                  thickness = 0.5.dp,
                  color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                )
              }
            }
          }
        } else {
          // Blocked list
          if (blockedList.isEmpty()) {
            Box(
              modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
              contentAlignment = Alignment.Center
            ) {
              Text(
                "No blocked users.",
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
              items(blockedList, key = { it.blockedUserId }) { blocked ->
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  UserAvatar(name = blocked.username, seed = blocked.blockedUserId, size = 40.dp)
                  Spacer(modifier = Modifier.width(14.dp))
                  Column(modifier = Modifier.weight(1f)) {
                    Text("@${blocked.username}", fontWeight = FontWeight.SemiBold)
                    Text("Blocked user", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                  }
                  IconButton(
                    onClick = {
                      scope.launch { userRepository.unblockUser(blocked.blockedUserId) }
                    }
                  ) {
                    Text("Unblock", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelMedium)
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  if (showAddContactDialog) {
    NewDirectChatDialog(
      userRepository = userRepository,
      onUserSelected = { profile ->
        scope.launch {
          userRepository.addContact(profile)
        }
      },
      onDismiss = { showAddContactDialog = false }
    )
  }
}
