package com.example.ui.auth

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.ui.common.AvatarPalette
import com.example.ui.common.UserAvatar

@Composable
fun ProfileSetupScreen(
  viewModel: AuthViewModel,
  onProfileCreated: () -> Unit,
  modifier: Modifier = Modifier
) {
  val currentUser by viewModel.currentUser.collectAsState()
  val uiState by viewModel.uiState.collectAsState()

  var username by remember { mutableStateOf("") }
  var displayName by remember { mutableStateOf(currentUser?.displayName ?: "") }
  var selectedAvatarSeed by remember { mutableStateOf("1") }
  val defaultPhone = remember(currentUser?.phoneNumber) {
    currentUser?.phoneNumber?.removePrefix("+880")?.removePrefix("0")?.trim() ?: ""
  }
  var bangladeshPhone by remember(defaultPhone) { mutableStateOf(defaultPhone) }
  var validationError by remember { mutableStateOf<String?>(null) }

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(24.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center
    ) {
      Text(
        text = "Set Up Your Identity",
        style = MaterialTheme.typography.headlineSmall,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onBackground
      )
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        text = "Choose your unique username and display name. Your family will connect with you via this username.",
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center
      )

      Spacer(modifier = Modifier.height(24.dp))

      // Preview Avatar
      UserAvatar(
        name = displayName.ifBlank { "User" },
        seed = selectedAvatarSeed,
        size = 80.dp
      )

      Spacer(modifier = Modifier.height(16.dp))

      // Avatar seed palette selector
      Text(
        text = "Choose Avatar Accent",
        style = MaterialTheme.typography.labelMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant
      )
      Spacer(modifier = Modifier.height(8.dp))
      Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        AvatarPalette.indices.forEach { index ->
          val seed = (index + 1).toString()
          val isSelected = selectedAvatarSeed == seed
          Box(
            modifier = Modifier
              .size(36.dp)
              .clip(CircleShape)
              .background(AvatarPalette[index])
              .clickable { selectedAvatarSeed = seed }
              .then(
                if (isSelected) Modifier.border(2.dp, MaterialTheme.colorScheme.primary, CircleShape)
                else Modifier
              ),
            contentAlignment = Alignment.Center
          ) {
            if (isSelected) {
              Icon(
                imageVector = Icons.Default.Check,
                contentDescription = "Selected",
                tint = Color.White,
                modifier = Modifier.size(18.dp)
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(24.dp))

      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
      ) {
        Column(modifier = Modifier.padding(20.dp)) {
          OutlinedTextField(
            value = username,
            onValueChange = {
              username = it.lowercase().filter { char -> char.isLetterOrDigit() || char == '_' || char == '.' }
            },
            label = { Text("Unique Username") },
            prefix = { Text("@") },
            placeholder = { Text("e.g. rahim_khan") },
            supportingText = { Text("3-30 letters, numbers, dot or underscore. No spaces.") },
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("username_input")
          )

          Spacer(modifier = Modifier.height(12.dp))

          OutlinedTextField(
            value = displayName,
            onValueChange = { displayName = it },
            label = { Text("Display Name") },
            placeholder = { Text("e.g. Rahim Khan") },
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("display_name_input")
          )

          Spacer(modifier = Modifier.height(12.dp))

          OutlinedTextField(
            value = bangladeshPhone,
            onValueChange = { bangladeshPhone = it },
            label = { Text("Phone Number (Optional)") },
            prefix = { Text("+880 ") },
            placeholder = { Text("1712345678") },
            supportingText = { Text("Protected in private record. Never shown to others.") },
            singleLine = true,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("setup_phone_input")
          )

          if (validationError != null) {
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = validationError!!,
              color = MaterialTheme.colorScheme.error,
              style = MaterialTheme.typography.bodySmall
            )
          }

          Spacer(modifier = Modifier.height(20.dp))

          Button(
            onClick = {
              val cleanUser = username.trim().lowercase()
              if (cleanUser.length < 3) {
                validationError = "Username must be at least 3 characters."
                return@Button
              }
              if (displayName.trim().isBlank()) {
                validationError = "Display name cannot be empty."
                return@Button
              }
              validationError = null
              val fullPhone = if (bangladeshPhone.isNotBlank()) "+880${bangladeshPhone.trim()}" else ""
              val email = currentUser?.email ?: ""
              viewModel.completeProfileSetup(
                username = cleanUser,
                displayName = displayName.trim(),
                avatarSeed = selectedAvatarSeed,
                phone = fullPhone,
                email = email,
                onSuccess = onProfileCreated
              )
            },
            modifier = Modifier
              .fillMaxWidth()
              .height(48.dp)
              .testTag("save_profile_button"),
            shape = RoundedCornerShape(12.dp),
            enabled = uiState !is AuthUiState.Loading
          ) {
            if (uiState is AuthUiState.Loading) {
              CircularProgressIndicator(
                modifier = Modifier.size(22.dp),
                color = MaterialTheme.colorScheme.onPrimary,
                strokeWidth = 2.dp
              )
            } else {
              Text("Complete Profile & Generate Keys", fontWeight = FontWeight.SemiBold)
            }
          }
        }
      }
    }
  }
}
