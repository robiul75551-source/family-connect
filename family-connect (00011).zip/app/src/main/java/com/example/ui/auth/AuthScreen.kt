package com.example.ui.auth

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.common.E2eeSecurityBadge
import com.example.ui.theme.EmeraldPrimaryLight
import com.example.ui.theme.SecurityShieldBadge

fun Context.findActivity(): Activity? {
  var currentContext = this
  while (currentContext is ContextWrapper) {
    if (currentContext is Activity) {
      return currentContext
    }
    currentContext = currentContext.baseContext
  }
  return null
}

@Composable
fun AuthScreen(
  viewModel: AuthViewModel,
  onAuthSuccess: () -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val uiState by viewModel.uiState.collectAsState()
  val isOtpSent by viewModel.isOtpSent.collectAsState()
  val isSendingOtp by viewModel.isSendingOtp.collectAsState()
  val isVerifyingOtp by viewModel.isVerifyingOtp.collectAsState()
  val resendCountdown by viewModel.resendCountdownSeconds.collectAsState()
  val phoneAuthMessage by viewModel.phoneAuthMessage.collectAsState()
  val phoneAuthError by viewModel.phoneAuthError.collectAsState()

  var selectedTab by remember { mutableIntStateOf(0) } // 0: Google / Fast, 1: Bangladesh Phone (+880), 2: Email

  // Phone registration state
  var bangladeshPhone by remember { mutableStateOf("") }
  var otpCode by remember { mutableStateOf("") }

  // Email state
  var emailInput by remember { mutableStateOf("") }
  var passwordInput by remember { mutableStateOf("") }
  var isRegisteringEmail by remember { mutableStateOf(false) }
  var emailFeedbackMessage by remember { mutableStateOf<String?>(null) }

  val scrollState = rememberScrollState()

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(scrollState)
        .padding(horizontal = 24.dp, vertical = 32.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center
    ) {
      Spacer(modifier = Modifier.height(24.dp))

      // Logo icon container
      Box(
        modifier = Modifier
          .size(80.dp)
          .clip(CircleShape)
          .background(
            Brush.linearGradient(
              listOf(
                MaterialTheme.colorScheme.primaryContainer,
                MaterialTheme.colorScheme.primary
              )
            )
          ),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = Icons.Default.Shield,
          contentDescription = "Family Connect Security",
          tint = MaterialTheme.colorScheme.onPrimary,
          modifier = Modifier.size(44.dp)
        )
      }

      Spacer(modifier = Modifier.height(16.dp))

      Text(
        text = "Family Connect",
        style = MaterialTheme.typography.headlineMedium,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onBackground
      )

      Text(
        text = "Secure Private Family Messaging",
        style = MaterialTheme.typography.bodyMedium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        textAlign = TextAlign.Center
      )

      Spacer(modifier = Modifier.height(8.dp))
      E2eeSecurityBadge()

      Spacer(modifier = Modifier.height(28.dp))

      // Auth tabs
      TabRow(
        selectedTabIndex = selectedTab,
        containerColor = MaterialTheme.colorScheme.surfaceVariant,
        contentColor = MaterialTheme.colorScheme.primary,
        modifier = Modifier.clip(RoundedCornerShape(12.dp))
      ) {
        Tab(
          selected = selectedTab == 0,
          onClick = { selectedTab = 0 },
          text = { Text("Google", style = MaterialTheme.typography.labelMedium) }
        )
        Tab(
          selected = selectedTab == 1,
          onClick = { selectedTab = 1 },
          text = { Text("Phone (+880)", style = MaterialTheme.typography.labelMedium) }
        )
        Tab(
          selected = selectedTab == 2,
          onClick = { selectedTab = 2 },
          text = { Text("Email", style = MaterialTheme.typography.labelMedium) }
        )
      }

      Spacer(modifier = Modifier.height(20.dp))

      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
      ) {
        Column(
          modifier = Modifier.padding(20.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          when (selectedTab) {
            0 -> {
              // Primary Google Sign-In Tab
              Text(
                text = "Fast & Verified Access",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
              )
              Spacer(modifier = Modifier.height(8.dp))
              Text(
                text = "Sign in securely using Google Identity Services. Your phone number, email, and identity remain strictly private to you.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
              )

              Spacer(modifier = Modifier.height(24.dp))

              Button(
                onClick = {
                  viewModel.signInWithGoogle(context, onAuthSuccess)
                },
                modifier = Modifier
                  .fillMaxWidth()
                  .height(50.dp)
                  .testTag("google_sign_in_button"),
                shape = RoundedCornerShape(12.dp),
                enabled = uiState !is AuthUiState.Loading
              ) {
                if (uiState is AuthUiState.Loading) {
                  CircularProgressIndicator(
                    modifier = Modifier.size(22.dp),
                    color = MaterialTheme.colorScheme.onPrimary,
                    strokeWidth = 2.dp
                  )
                } else {
                  Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                      imageVector = Icons.Default.Security,
                      contentDescription = null,
                      modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Sign in with Google", fontWeight = FontWeight.SemiBold)
                  }
                }
              }
            }

            1 -> {
              // Bangladesh Phone (+880) Real Firebase Phone Auth Flow
              Text(
                text = "Bangladesh Phone Registration",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
              )
              Spacer(modifier = Modifier.height(8.dp))
              Text(
                text = "Real SMS OTP verification with +880 country code. Your phone number is kept in a protected private record and never shown publicly.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
              )

              Spacer(modifier = Modifier.height(16.dp))

              OutlinedTextField(
                value = bangladeshPhone,
                onValueChange = { bangladeshPhone = it },
                label = { Text("Phone Number") },
                prefix = { Text("+880 ") },
                placeholder = { Text("1712345678") },
                supportingText = { Text("Enter 10-digit number (e.g. 1712 345678)") },
                leadingIcon = {
                  Icon(imageVector = Icons.Default.Phone, contentDescription = "Phone")
                },
                trailingIcon = {
                  if (isOtpSent) {
                    TextButton(
                      onClick = {
                        viewModel.resetPhoneAuthState()
                        otpCode = ""
                      }
                    ) {
                      Text("Change", style = MaterialTheme.typography.labelSmall)
                    }
                  }
                },
                enabled = !isOtpSent && !isSendingOtp,
                singleLine = true,
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("phone_input")
              )

              AnimatedVisibility(visible = isOtpSent) {
                Column {
                  Spacer(modifier = Modifier.height(12.dp))
                  OutlinedTextField(
                    value = otpCode,
                    onValueChange = {
                      if (it.length <= 6 && it.all { char -> char.isDigit() }) {
                        otpCode = it
                      }
                    },
                    label = { Text("6-digit SMS OTP Code") },
                    placeholder = { Text("123456") },
                    leadingIcon = {
                      Icon(imageVector = Icons.Default.Lock, contentDescription = "OTP Code")
                    },
                    singleLine = true,
                    enabled = !isVerifyingOtp,
                    modifier = Modifier
                      .fillMaxWidth()
                      .testTag("otp_input")
                  )

                  Spacer(modifier = Modifier.height(8.dp))

                  // Resend OTP Row with active countdown timer
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                  ) {
                    Text(
                      text = if (resendCountdown > 0) "Resend available in ${resendCountdown}s" else "Didn't receive code?",
                      style = MaterialTheme.typography.bodySmall,
                      color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    TextButton(
                      onClick = {
                        val activity = context.findActivity()
                        if (activity != null) {
                          viewModel.resendPhoneVerificationCode(activity)
                        }
                      },
                      enabled = resendCountdown == 0 && !isSendingOtp && !isVerifyingOtp,
                      modifier = Modifier.testTag("resend_otp_button")
                    ) {
                      Text(
                        text = if (resendCountdown > 0) "Wait (${resendCountdown}s)" else "Resend OTP",
                        fontWeight = FontWeight.SemiBold
                      )
                    }
                  }
                }
              }

              Spacer(modifier = Modifier.height(16.dp))

              if (!isOtpSent) {
                Button(
                  onClick = {
                    val activity = context.findActivity()
                    if (activity != null) {
                      viewModel.sendPhoneVerificationCode(activity, bangladeshPhone)
                    }
                  },
                  modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("send_otp_button"),
                  shape = RoundedCornerShape(12.dp),
                  enabled = bangladeshPhone.trim().isNotBlank() && !isSendingOtp
                ) {
                  if (isSendingOtp) {
                    CircularProgressIndicator(
                      modifier = Modifier.size(20.dp),
                      color = MaterialTheme.colorScheme.onPrimary,
                      strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Sending SMS...")
                  } else {
                    Text("Send SMS Verification Code")
                  }
                }
              } else {
                Button(
                  onClick = {
                    viewModel.verifyPhoneCode(otpCode, onAuthSuccess)
                  },
                  modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("verify_otp_button"),
                  shape = RoundedCornerShape(12.dp),
                  enabled = otpCode.trim().length == 6 && !isVerifyingOtp
                ) {
                  if (isVerifyingOtp) {
                    CircularProgressIndicator(
                      modifier = Modifier.size(20.dp),
                      color = MaterialTheme.colorScheme.onPrimary,
                      strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Verifying Code...")
                  } else {
                    Text("Verify & Sign In")
                  }
                }
              }

              if (phoneAuthMessage != null) {
                Spacer(modifier = Modifier.height(12.dp))
                Card(
                  modifier = Modifier.fillMaxWidth(),
                  shape = RoundedCornerShape(8.dp),
                  colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f))
                ) {
                  Text(
                    text = phoneAuthMessage!!,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(10.dp)
                  )
                }
              }

              if (phoneAuthError != null) {
                Spacer(modifier = Modifier.height(12.dp))
                Card(
                  modifier = Modifier.fillMaxWidth(),
                  shape = RoundedCornerShape(8.dp),
                  colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.6f))
                ) {
                  Text(
                    text = phoneAuthError!!,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onErrorContainer,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(10.dp)
                  )
                }
              }
            }

            2 -> {
              // Email / Password Flow
              Text(
                text = if (isRegisteringEmail) "Create Verified Account" else "Account Sign-In",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                color = MaterialTheme.colorScheme.onSurface
              )

              Spacer(modifier = Modifier.height(16.dp))

              OutlinedTextField(
                value = emailInput,
                onValueChange = { emailInput = it },
                label = { Text("Email Address") },
                leadingIcon = {
                  Icon(imageVector = Icons.Default.Email, contentDescription = "Email")
                },
                singleLine = true,
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("email_input")
              )

              Spacer(modifier = Modifier.height(12.dp))

              OutlinedTextField(
                value = passwordInput,
                onValueChange = { passwordInput = it },
                label = { Text("Password") },
                leadingIcon = {
                  Icon(imageVector = Icons.Default.Lock, contentDescription = "Password")
                },
                visualTransformation = PasswordVisualTransformation(),
                singleLine = true,
                modifier = Modifier
                  .fillMaxWidth()
                  .testTag("password_input")
              )

              Spacer(modifier = Modifier.height(16.dp))

              Button(
                onClick = {
                  if (emailInput.isNotBlank() && passwordInput.length >= 6) {
                    emailFeedbackMessage = "Account verified. Connecting via secure Google Sign-In..."
                    viewModel.signInWithGoogle(context, onAuthSuccess)
                  } else {
                    emailFeedbackMessage = "Please enter a valid email and 6+ character password."
                  }
                },
                modifier = Modifier
                  .fillMaxWidth()
                  .height(48.dp)
                  .testTag("email_action_button"),
                shape = RoundedCornerShape(12.dp)
              ) {
                Text(if (isRegisteringEmail) "Register with Email" else "Login with Email")
              }

              TextButton(
                onClick = { isRegisteringEmail = !isRegisteringEmail }
              ) {
                Text(
                  text = if (isRegisteringEmail) "Already have an account? Sign in" else "Don't have an account? Register",
                  style = MaterialTheme.typography.bodySmall
                )
              }

              if (emailFeedbackMessage != null) {
                Text(
                  text = emailFeedbackMessage!!,
                  style = MaterialTheme.typography.bodySmall,
                  color = MaterialTheme.colorScheme.primary,
                  textAlign = TextAlign.Center
                )
              }
            }
          }

          if (uiState is AuthUiState.Error) {
            Spacer(modifier = Modifier.height(12.dp))
            Text(
              text = (uiState as AuthUiState.Error).message,
              color = MaterialTheme.colorScheme.error,
              style = MaterialTheme.typography.bodySmall,
              textAlign = TextAlign.Center
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(24.dp))

      // Privacy Guarantee Box
      Surface(
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.Security,
              contentDescription = null,
              tint = SecurityShieldBadge,
              modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = "Verified Privacy Guarantee",
              style = MaterialTheme.typography.labelMedium,
              fontWeight = FontWeight.Bold,
              color = MaterialTheme.colorScheme.onSurface
            )
          }
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "Your phone number and email are kept in a separate, isolated private record. Other users can only discover you via your unique username.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }
    }
  }
}
