package com.example.ui.chat

import android.content.Context
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.crypto.CryptoManager
import com.example.data.model.ChatMessage
import com.example.data.model.Conversation
import com.example.data.model.UserProfile
import com.example.data.repository.ChatRepository
import com.example.data.repository.UserRepository
import com.google.firebase.Firebase
import com.google.firebase.auth.auth
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.security.PrivateKey
import javax.crypto.SecretKey

data class DecryptedMessage(
  val message: ChatMessage,
  val decryptedText: String,
  val isDecryptionSuccessful: Boolean = true
)

sealed interface ChatUiState {
  object Loading : ChatUiState
  data class Success(val conversations: List<Conversation>) : ChatUiState
  data class Error(val message: String) : ChatUiState
}

class ChatViewModel(
  private val chatRepository: ChatRepository,
  private val userRepository: UserRepository,
  private val context: Context
) : ViewModel() {

  private val auth = Firebase.auth
  val currentUserId: String get() = auth.currentUser?.uid ?: ""

  val conversationsState: StateFlow<ChatUiState> = chatRepository.observeConversations()
    .map<List<Conversation>, ChatUiState> { ChatUiState.Success(it) }
    .catch { emit(ChatUiState.Error(it.message ?: "Failed to observe conversations")) }
    .stateIn(
      scope = viewModelScope,
      started = SharingStarted.WhileSubscribed(5000L),
      initialValue = ChatUiState.Loading
    )

  private val _activeConversation = MutableStateFlow<Conversation?>(null)
  val activeConversation = _activeConversation.asStateFlow()

  private val _activeMessages = MutableStateFlow<List<DecryptedMessage>>(emptyList())
  val activeMessages = _activeMessages.asStateFlow()

  private val _participantProfiles = MutableStateFlow<Map<String, UserProfile>>(emptyMap())
  val participantProfiles = _participantProfiles.asStateFlow()

  private val _isSending = MutableStateFlow(false)
  val isSending = _isSending.asStateFlow()

  private val _errorMessage = MutableStateFlow<String?>(null)
  val errorMessage = _errorMessage.asStateFlow()

  fun setActiveConversation(conversation: Conversation) {
    _activeConversation.value = conversation
    loadParticipantProfiles(conversation.participantUids)
    observeMessagesForConversation(conversation.conversationId)
  }

  fun clearActiveConversation() {
    _activeConversation.value = null
    _activeMessages.value = emptyList()
  }

  fun clearError() {
    _errorMessage.value = null
  }

  private fun loadParticipantProfiles(uids: List<String>) {
    viewModelScope.launch {
      val profileMap = mutableMapOf<String, UserProfile>()
      for (uid in uids) {
        try {
          userRepository.observeUserProfile(uid).collect { profile ->
            if (profile != null) {
              profileMap[uid] = profile
              _participantProfiles.value = profileMap.toMap()
              // Re-decrypt messages if participant public keys become available
              _activeConversation.value?.let { conv ->
                decryptCurrentMessages(conv, _activeMessages.value.map { it.message })
              }
            }
          }
        } catch (e: Exception) {
          Log.w("ChatViewModel", "Could not load profile for $uid", e)
        }
      }
    }
  }

  private fun observeMessagesForConversation(conversationId: String) {
    viewModelScope.launch {
      chatRepository.observeMessages(conversationId).collect { rawMessages ->
        _activeConversation.value?.let { conv ->
          decryptCurrentMessages(conv, rawMessages)
        }
      }
    }
  }

  /**
   * Genuine Client-Side E2EE Decryption:
   * Direct Messages: Decrypt with shared ECDH secret between sender & recipient.
   * Group Messages: Unwrap per-recipient symmetric key envelope, decrypt message.
   */
  private fun decryptCurrentMessages(conv: Conversation, rawMessages: List<ChatMessage>) {
    val keyPair = CryptoManager.getOrCreateDeviceKeyPair(context)
    val profiles = _participantProfiles.value
    val decryptedList = mutableListOf<DecryptedMessage>()

    for (msg in rawMessages) {
      if (msg.deletedForEveryone) {
        decryptedList.add(DecryptedMessage(msg, "This message was deleted.", true))
        continue
      }

      val text = try {
        if (conv.type == "direct") {
          // Identify the other participant's public key
          val peerUid = if (msg.senderId == currentUserId) {
            conv.participantUids.firstOrNull { it != currentUserId } ?: currentUserId
          } else {
            msg.senderId
          }
          val peerProfile = profiles[peerUid]
          val peerPubKey = peerProfile?.publicKey

          if (peerPubKey.isNullOrBlank()) {
            "[Waiting for encryption key]"
          } else {
            val sharedKey = CryptoManager.deriveSharedSecret(keyPair.private, peerPubKey)
            CryptoManager.decryptAesGcm(msg.ciphertext, msg.iv, sharedKey)
          }
        } else {
          // Group chat
          val senderProfile = profiles[msg.senderId]
          val senderPubKey = senderProfile?.publicKey

          if (senderPubKey.isNullOrBlank()) {
            "[Waiting for sender key]"
          } else {
            val unwrappedGroupKey = CryptoManager.unwrapGroupKey(
              encryptedKeyMapJson = msg.encryptedKeyMap,
              currentUserId = currentUserId,
              senderPublicKeyBase64 = senderPubKey,
              localPrivateKey = keyPair.private
            )
            if (unwrappedGroupKey != null) {
              CryptoManager.decryptAesGcm(msg.ciphertext, msg.iv, unwrappedGroupKey)
            } else {
              "[Encrypted Group Message]"
            }
          }
        }
      } catch (e: Exception) {
        "[Unable to decrypt message]"
      }

      decryptedList.add(DecryptedMessage(msg, text, !text.startsWith("[Unable")))
    }

    _activeMessages.value = decryptedList
  }

  fun sendTextMessage(text: String) {
    val conv = _activeConversation.value ?: return
    if (text.trim().isBlank()) return

    _isSending.value = true
    viewModelScope.launch {
      val profiles = _participantProfiles.value

      val targetUserPubKey = if (conv.type == "direct") {
        val otherUid = conv.participantUids.firstOrNull { it != currentUserId }
        profiles[otherUid]?.publicKey
      } else null

      val groupPubKeys = if (conv.type == "group") {
        profiles.mapValues { it.value.publicKey }.filterValues { it.isNotBlank() }
      } else emptyMap()

      val result = chatRepository.sendEncryptedMessage(
        conversation = conv,
        plaintext = text.trim(),
        targetUserPublicKeyBase64 = targetUserPubKey,
        groupMembersPublicKeys = groupPubKeys,
        messageType = "text"
      )

      _isSending.value = false
      if (result.isFailure) {
        _errorMessage.value = result.exceptionOrNull()?.localizedMessage ?: "Failed to send encrypted message."
      }
    }
  }

  fun sendMediaAttachment(fileName: String, fileType: String, simulatedBytes: ByteArray) {
    val conv = _activeConversation.value ?: return
    _isSending.value = true

    viewModelScope.launch {
      val profiles = _participantProfiles.value
      val targetUserPubKey = if (conv.type == "direct") {
        val otherUid = conv.participantUids.firstOrNull { it != currentUserId }
        profiles[otherUid]?.publicKey
      } else null

      val groupPubKeys = if (conv.type == "group") {
        profiles.mapValues { it.value.publicKey }.filterValues { it.isNotBlank() }
      } else emptyMap()

      val result = chatRepository.sendEncryptedMessage(
        conversation = conv,
        plaintext = "Attached File: $fileName (${simulatedBytes.size} bytes)",
        targetUserPublicKeyBase64 = targetUserPubKey,
        groupMembersPublicKeys = groupPubKeys,
        messageType = if (fileType.startsWith("image")) "image" else "file",
        fileName = fileName,
        fileSize = simulatedBytes.size.toLong()
      )

      _isSending.value = false
      if (result.isFailure) {
        _errorMessage.value = result.exceptionOrNull()?.localizedMessage ?: "Failed to upload file."
      }
    }
  }

  fun deleteForEveryone(messageId: String) {
    val conv = _activeConversation.value ?: return
    viewModelScope.launch {
      chatRepository.deleteMessageForEveryone(conv.conversationId, messageId)
    }
  }

  fun startDirectChat(targetUser: UserProfile, onComplete: (Conversation) -> Unit) {
    viewModelScope.launch {
      val res = chatRepository.getOrCreateDirectConversation(targetUser)
      if (res.isSuccess) {
        val conv = res.getOrNull()!!
        setActiveConversation(conv)
        onComplete(conv)
      } else {
        _errorMessage.value = res.exceptionOrNull()?.localizedMessage ?: "Failed to start direct conversation."
      }
    }
  }

  fun createGroup(name: String, memberUids: List<String>, onComplete: (Conversation) -> Unit) {
    viewModelScope.launch {
      val res = chatRepository.createFamilyGroup(name, memberUids)
      if (res.isSuccess) {
        val conv = res.getOrNull()!!
        setActiveConversation(conv)
        onComplete(conv)
      } else {
        _errorMessage.value = res.exceptionOrNull()?.localizedMessage ?: "Failed to create group."
      }
    }
  }

  fun joinGroupByCode(inviteCode: String, onComplete: (Conversation) -> Unit) {
    viewModelScope.launch {
      val res = chatRepository.joinGroupByInviteCode(inviteCode)
      if (res.isSuccess) {
        val conv = res.getOrNull()!!
        setActiveConversation(conv)
        onComplete(conv)
      } else {
        _errorMessage.value = res.exceptionOrNull()?.localizedMessage ?: "Could not join family group."
      }
    }
  }
}
