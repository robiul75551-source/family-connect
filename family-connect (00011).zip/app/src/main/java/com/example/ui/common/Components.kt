package com.example.ui.common

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.OnlineGreen
import com.example.ui.theme.SecurityShieldBadge

val AvatarPalette = listOf(
  Color(0xFF0D9488), // Teal
  Color(0xFF3B82F6), // Blue
  Color(0xFF8B5CF6), // Purple
  Color(0xFFEC4899), // Pink
  Color(0xFFF59E0B), // Amber
  Color(0xFF10B981)  // Emerald
)

@Composable
fun UserAvatar(
  name: String,
  seed: String = "1",
  size: Dp = 44.dp,
  isGroup: Boolean = false,
  showOnlineBadge: Boolean = false,
  isOnline: Boolean = false,
  modifier: Modifier = Modifier
) {
  val colorIndex = (seed.hashCode() and 0x7FFFFFFF) % AvatarPalette.size
  val bgColor = if (isGroup) Color(0xFF475569) else AvatarPalette[colorIndex]
  val initial = name.trim().firstOrNull()?.uppercaseChar()?.toString() ?: if (isGroup) "G" else "U"

  Box(modifier = modifier.size(size)) {
    Box(
      modifier = Modifier
        .size(size)
        .clip(CircleShape)
        .background(bgColor)
        .testTag("user_avatar"),
      contentAlignment = Alignment.Center
    ) {
      if (isGroup) {
        Icon(
          imageVector = Icons.Default.Group,
          contentDescription = "Group Avatar",
          tint = Color.White,
          modifier = Modifier.size(size * 0.55f)
        )
      } else {
        Text(
          text = initial,
          color = Color.White,
          fontSize = (size.value * 0.42f).sp,
          fontWeight = FontWeight.Bold
        )
      }
    }

    if (showOnlineBadge && !isGroup) {
      Box(
        modifier = Modifier
          .size(size * 0.32f)
          .align(Alignment.BottomEnd)
          .clip(CircleShape)
          .background(MaterialTheme.colorScheme.surface)
          .padding(2.dp)
      ) {
        Box(
          modifier = Modifier
            .matchParentSize()
            .clip(CircleShape)
            .background(if (isOnline) OnlineGreen else Color(0xFF94A3B8))
        )
      }
    }
  }
}

@Composable
fun E2eeSecurityBadge(modifier: Modifier = Modifier) {
  Surface(
    shape = RoundedCornerShape(12.dp),
    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
    modifier = modifier.testTag("e2ee_security_badge")
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(
        imageVector = Icons.Default.Lock,
        contentDescription = "Encrypted",
        tint = SecurityShieldBadge,
        modifier = Modifier.size(13.dp)
      )
      Spacer(modifier = Modifier.width(4.dp))
      Text(
        text = "End-to-End Encrypted",
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.onPrimaryContainer,
        fontWeight = FontWeight.Medium
      )
    }
  }
}
