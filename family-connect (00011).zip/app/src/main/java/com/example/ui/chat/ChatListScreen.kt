package com.example.ui.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.GroupAdd
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Conversation
import com.example.data.model.UserProfile
import com.example.ui.common.E2eeSecurityBadge
import com.example.ui.common.UserAvatar
import java.text.SimpleDateFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatListScreen(
  viewModel: ChatViewModel,
  myProfile: UserProfile?,
  onConversationSelected: (Conversation) -> Unit,
  onOpenNewChat: () -> Unit,
  onOpenCreateGroup: () -> Unit,
  onOpenJoinGroup: () -> Unit,
  onOpenProfile: () -> Unit,
  modifier: Modifier = Modifier
) {
  val conversationsState by viewModel.conversationsState.collectAsState()
  var searchQuery by remember { mutableStateOf("") }
  var selectedFilter by remember { mutableIntStateOf(0) } // 0: All, 1: Groups, 2: Direct
  var showActionSheet by remember { mutableStateOf(false) }
  val sheetState = rememberModalBottomSheetState()

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = "Family Connect",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
              )
              Spacer(modifier = Modifier.width(6.dp))
              Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = "Encrypted",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(16.dp)
              )
            }
            Text(
              text = if (myProfile != null) "@${myProfile.username}" else "Secure Private Messaging",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        },
        actions = {
          if (myProfile != null) {
            IconButton(
              onClick = onOpenProfile,
              modifier = Modifier.testTag("profile_top_button")
            ) {
              UserAvatar(
                name = myProfile.displayName,
                seed = myProfile.avatarSeed,
                size = 36.dp
              )
            }
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = MaterialTheme.colorScheme.surface
        )
      )
    },
    floatingActionButton = {
      FloatingActionButton(
        onClick = { showActionSheet = true },
        containerColor = MaterialTheme.colorScheme.primary,
        contentColor = MaterialTheme.colorScheme.onPrimary,
        shape = CircleShape,
        modifier = Modifier.testTag("new_chat_fab")
      ) {
        Icon(imageVector = Icons.Default.Add, contentDescription = "New Conversation")
      }
    },
    modifier = modifier.testTag("chat_list_screen")
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .background(MaterialTheme.colorScheme.background)
    ) {
      // Search bar
      Box(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        OutlinedTextField(
          value = searchQuery,
          onValueChange = { searchQuery = it },
          placeholder = { Text("Search conversations...") },
          leadingIcon = {
            Icon(imageVector = Icons.Default.Search, contentDescription = "Search")
          },
          singleLine = true,
          shape = RoundedCornerShape(24.dp),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("search_conversations_input")
        )
      }

      // Filter chips
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        FilterChip(
          selected = selectedFilter == 0,
          onClick = { selectedFilter = 0 },
          label = { Text("All") },
          modifier = Modifier.testTag("filter_all")
        )
        FilterChip(
          selected = selectedFilter == 1,
          onClick = { selectedFilter = 1 },
          label = { Text("Family Groups") },
          modifier = Modifier.testTag("filter_groups")
        )
        FilterChip(
          selected = selectedFilter == 2,
          onClick = { selectedFilter = 2 },
          label = { Text("Direct") },
          modifier = Modifier.testTag("filter_direct")
        )
      }

      Spacer(modifier = Modifier.height(4.dp))

      when (val state = conversationsState) {
        is ChatUiState.Loading -> {
          Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
          ) {
            CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
          }
        }

        is ChatUiState.Error -> {
          Box(
            modifier = Modifier
              .fillMaxSize()
              .padding(24.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              text = state.message,
              color = MaterialTheme.colorScheme.error,
              style = MaterialTheme.typography.bodyMedium
            )
          }
        }

        is ChatUiState.Success -> {
          val filtered = state.conversations.filter { conv ->
            val matchesFilter = when (selectedFilter) {
              1 -> conv.type == "group"
              2 -> conv.type == "direct"
              else -> true
            }
            val matchesQuery = if (searchQuery.isBlank()) true else {
              conv.name.contains(searchQuery, ignoreCase = true)
            }
            matchesFilter && matchesQuery
          }

          if (filtered.isEmpty()) {
            EmptyConversationsView(
              onNewChat = onOpenNewChat,
              onCreateGroup = onOpenCreateGroup,
              onJoinGroup = onOpenJoinGroup
            )
          } else {
            LazyColumn(modifier = Modifier.fillMaxSize()) {
              items(filtered, key = { it.conversationId }) { conv ->
                ConversationItem(
                  conversation = conv,
                  onClick = { onConversationSelected(conv) }
                )
                HorizontalDivider(
                  modifier = Modifier.padding(start = 76.dp),
                  thickness = 0.5.dp,
                  color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)
                )
              }
            }
          }
        }
      }
    }
  }

  // FAB Action Modal Bottom Sheet
  if (showActionSheet) {
    ModalBottomSheet(
      onDismissRequest = { showActionSheet = false },
      sheetState = sheetState
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 24.dp, vertical = 16.dp)
      ) {
        Text(
          text = "Start Conversation",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = MaterialTheme.colorScheme.onSurface
        )
        Spacer(modifier = Modifier.height(16.dp))

        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable {
              showActionSheet = false
              onOpenNewChat()
            }
            .padding(14.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(44.dp)
              .clip(CircleShape)
              .background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.PersonAdd,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.primary
            )
          }
          Spacer(modifier = Modifier.width(16.dp))
          Column {
            Text("Private Direct Chat", fontWeight = FontWeight.SemiBold)
            Text(
              "Search family member by unique username",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }

        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable {
              showActionSheet = false
              onOpenCreateGroup()
            }
            .padding(14.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(44.dp)
              .clip(CircleShape)
              .background(MaterialTheme.colorScheme.secondaryContainer),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.GroupAdd,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.secondary
            )
          }
          Spacer(modifier = Modifier.width(16.dp))
          Column {
            Text("Create Family Group", fontWeight = FontWeight.SemiBold)
            Text(
              "Encrypted group for whole family with invite code",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }

        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable {
              showActionSheet = false
              onOpenJoinGroup()
            }
            .padding(14.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(44.dp)
              .clip(CircleShape)
              .background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.QrCode,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.onSurface
            )
          }
          Spacer(modifier = Modifier.width(16.dp))
          Column {
            Text("Join with Invite Code", fontWeight = FontWeight.SemiBold)
            Text(
              "Enter 6-digit family invitation code",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
        Spacer(modifier = Modifier.height(24.dp))
      }
    }
  }
}

@Composable
fun ConversationItem(
  conversation: Conversation,
  onClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  val isGroup = conversation.type == "group"
  val timeFormat = remember { SimpleDateFormat("hh:mm a", Locale.getDefault()) }
  val timeString = conversation.lastMessageTimestamp?.toDate()?.let { timeFormat.format(it) } ?: ""

  Row(
    modifier = modifier
      .fillMaxWidth()
      .clickable(onClick = onClick)
      .padding(horizontal = 16.dp, vertical = 12.dp)
      .testTag("conversation_item_${conversation.conversationId}"),
    verticalAlignment = Alignment.CenterVertically
  ) {
    UserAvatar(
      name = conversation.name.ifBlank { if (isGroup) "Family Group" else "Direct Chat" },
      seed = conversation.conversationId,
      size = 52.dp,
      isGroup = isGroup
    )

    Spacer(modifier = Modifier.width(14.dp))

    Column(modifier = Modifier.weight(1f)) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = conversation.name.ifBlank { if (isGroup) "Family Group" else "Direct Chat" },
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.SemiBold,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
          color = MaterialTheme.colorScheme.onSurface,
          modifier = Modifier.weight(1f, fill = false)
        )

        if (timeString.isNotBlank()) {
          Text(
            text = timeString,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }

      Spacer(modifier = Modifier.height(3.dp))

      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = Icons.Default.Lock,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.primary,
          modifier = Modifier.size(12.dp)
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
          text = conversation.lastMessageTextEncrypted.ifBlank { "Tap to open encrypted chat" },
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
      }
    }
  }
}

@Composable
fun EmptyConversationsView(
  onNewChat: () -> Unit,
  onCreateGroup: () -> Unit,
  onJoinGroup: () -> Unit
) {
  Column(
    modifier = Modifier
      .fillMaxSize()
      .padding(32.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center
  ) {
    Box(
      modifier = Modifier
        .size(80.dp)
        .clip(CircleShape)
        .background(MaterialTheme.colorScheme.primaryContainer),
      contentAlignment = Alignment.Center
    ) {
      Icon(
        imageVector = Icons.Default.Shield,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.primary,
        modifier = Modifier.size(40.dp)
      )
    }

    Spacer(modifier = Modifier.height(20.dp))

    Text(
      text = "Your Private Family Space",
      style = MaterialTheme.typography.titleLarge,
      fontWeight = FontWeight.Bold,
      color = MaterialTheme.colorScheme.onBackground
    )

    Spacer(modifier = Modifier.height(8.dp))

    Text(
      text = "Messages and files are encrypted on your device with AES-256-GCM. Connect with family members using their unique username without exposing phone numbers.",
      style = MaterialTheme.typography.bodyMedium,
      color = MaterialTheme.colorScheme.onSurfaceVariant,
      textAlign = androidx.compose.ui.text.style.TextAlign.Center
    )

    Spacer(modifier = Modifier.height(24.dp))

    Surface(
      shape = RoundedCornerShape(12.dp),
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 1.dp,
      modifier = Modifier
        .fillMaxWidth()
        .clickable(onClick = onNewChat)
        .padding(4.dp)
    ) {
      Row(
        modifier = Modifier.padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(
          imageVector = Icons.Default.PersonAdd,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.primary
        )
        Spacer(modifier = Modifier.width(12.dp))
        Text("Find family member by @username", fontWeight = FontWeight.Medium)
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    Surface(
      shape = RoundedCornerShape(12.dp),
      color = MaterialTheme.colorScheme.surface,
      tonalElevation = 1.dp,
      modifier = Modifier
        .fillMaxWidth()
        .clickable(onClick = onCreateGroup)
        .padding(4.dp)
    ) {
      Row(
        modifier = Modifier.padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(
          imageVector = Icons.Default.GroupAdd,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.secondary
        )
        Spacer(modifier = Modifier.width(12.dp))
        Text("Create Family Group with Invite Code", fontWeight = FontWeight.Medium)
      }
    }
  }
}
