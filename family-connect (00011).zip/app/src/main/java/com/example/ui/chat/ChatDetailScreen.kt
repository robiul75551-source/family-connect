package com.example.ui.chat

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Conversation
import com.example.ui.common.E2eeSecurityBadge
import com.example.ui.common.UserAvatar
import com.example.ui.theme.BubbleOtherDark
import com.example.ui.theme.BubbleOtherLight
import com.example.ui.theme.BubbleSelfDark
import com.example.ui.theme.BubbleSelfLight
import java.text.SimpleDateFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatDetailScreen(
  conversation: Conversation,
  viewModel: ChatViewModel,
  onNavigateBack: () -> Unit,
  onOpenGroupInfo: () -> Unit,
  modifier: Modifier = Modifier
) {
  BackHandler {
    viewModel.clearActiveConversation()
    onNavigateBack()
  }

  val messages by viewModel.activeMessages.collectAsState()
  val participantProfiles by viewModel.participantProfiles.collectAsState()
  val currentUserId = viewModel.currentUserId
  val isGroup = conversation.type == "group"

  var inputText by remember { mutableStateOf("") }
  var showAttachmentSheet by remember { mutableStateOf(false) }
  var selectedMessageForMenu by remember { mutableStateOf<DecryptedMessage?>(null) }
  val clipboardManager = LocalClipboardManager.current

  val listState = rememberLazyListState()

  LaunchedEffect(messages.size) {
    if (messages.isNotEmpty()) {
      listState.animateScrollToItem(messages.size - 1)
    }
  }

  Scaffold(
    topBar = {
      TopAppBar(
        title = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            UserAvatar(
              name = conversation.name.ifBlank { if (isGroup) "Group" else "Direct" },
              seed = conversation.conversationId,
              size = 40.dp,
              isGroup = isGroup
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                text = conversation.name.ifBlank { if (isGroup) "Family Group" else "Direct Chat" },
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1
              )
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = Icons.Default.Lock,
                  contentDescription = null,
                  tint = MaterialTheme.colorScheme.primary,
                  modifier = Modifier.size(11.dp)
                )
                Spacer(modifier = Modifier.width(3.dp))
                Text(
                  text = if (isGroup) "${conversation.participantUids.size} family members" else "E2EE Verified",
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.primary
                )
              }
            }
          }
        },
        navigationIcon = {
          IconButton(
            onClick = {
              viewModel.clearActiveConversation()
              onNavigateBack()
            },
            modifier = Modifier.testTag("chat_back_button")
          ) {
            Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
          }
        },
        actions = {
          if (isGroup) {
            IconButton(
              onClick = onOpenGroupInfo,
              modifier = Modifier.testTag("group_info_button")
            ) {
              Icon(imageVector = Icons.Default.Info, contentDescription = "Group Info")
            }
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(
          containerColor = MaterialTheme.colorScheme.surface
        )
      )
    },
    modifier = modifier.testTag("chat_detail_screen")
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .background(MaterialTheme.colorScheme.background)
        .imePadding()
    ) {
      // E2EE Info banner top
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
          .padding(vertical = 6.dp, horizontal = 16.dp),
        contentAlignment = Alignment.Center
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.Security,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(13.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "Messages are end-to-end encrypted with AES-256-GCM. No third party can read them.",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
          )
        }
      }

      // Messages list
      LazyColumn(
        state = listState,
        modifier = Modifier
          .weight(1f)
          .fillMaxWidth()
          .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        items(messages, key = { it.message.messageId }) { decMsg ->
          MessageBubble(
            decryptedMessage = decMsg,
            isFromMe = decMsg.message.senderId == currentUserId,
            senderProfile = participantProfiles[decMsg.message.senderId],
            isGroup = isGroup,
            onLongClick = { selectedMessageForMenu = decMsg }
          )
        }
      }

      // Input bottom bar
      Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 3.dp,
        modifier = Modifier
          .fillMaxWidth()
          .navigationBarsPadding()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          IconButton(
            onClick = { showAttachmentSheet = true },
            modifier = Modifier.testTag("attach_file_button")
          ) {
            Icon(
              imageVector = Icons.Default.AttachFile,
              contentDescription = "Attach file",
              tint = MaterialTheme.colorScheme.primary
            )
          }

          OutlinedTextField(
            value = inputText,
            onValueChange = { inputText = it },
            placeholder = { Text("Encrypted message...") },
            maxLines = 4,
            shape = RoundedCornerShape(24.dp),
            colors = OutlinedTextFieldDefaults.colors(
              focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
              unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
            ),
            modifier = Modifier
              .weight(1f)
              .testTag("message_input_field")
          )

          Spacer(modifier = Modifier.width(8.dp))

          IconButton(
            onClick = {
              if (inputText.isNotBlank()) {
                val textToSend = inputText
                inputText = ""
                viewModel.sendTextMessage(textToSend)
              }
            },
            enabled = inputText.isNotBlank(),
            modifier = Modifier
              .size(44.dp)
              .clip(CircleShape)
              .background(
                if (inputText.isNotBlank()) MaterialTheme.colorScheme.primary
                else MaterialTheme.colorScheme.surfaceVariant
              )
              .testTag("send_message_button")
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.Send,
              contentDescription = "Send",
              tint = if (inputText.isNotBlank()) MaterialTheme.colorScheme.onPrimary
              else MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }
      }
    }
  }

  // Attachment Sheet
  if (showAttachmentSheet) {
    ModalBottomSheet(
      onDismissRequest = { showAttachmentSheet = false }
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(24.dp)
      ) {
        Text(
          text = "Share Encrypted File",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(16.dp))

        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable {
              showAttachmentSheet = false
              viewModel.sendMediaAttachment(
                fileName = "family_photo_${System.currentTimeMillis() % 1000}.jpg",
                fileType = "image/jpeg",
                simulatedBytes = ByteArray(1024 * 48) // 48 KB
              )
            }
            .padding(12.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(imageVector = Icons.Default.Image, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
          Spacer(modifier = Modifier.width(16.dp))
          Column {
            Text("Photo / Image", fontWeight = FontWeight.SemiBold)
            Text("Encrypted on device before transmission", style = MaterialTheme.typography.bodySmall)
          }
        }

        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable {
              showAttachmentSheet = false
              viewModel.sendMediaAttachment(
                fileName = "family_document_${System.currentTimeMillis() % 1000}.pdf",
                fileType = "application/pdf",
                simulatedBytes = ByteArray(1024 * 128) // 128 KB
              )
            }
            .padding(12.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(imageVector = Icons.Default.Description, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
          Spacer(modifier = Modifier.width(16.dp))
          Column {
            Text("PDF / Document", fontWeight = FontWeight.SemiBold)
            Text("Secure authenticated file envelope", style = MaterialTheme.typography.bodySmall)
          }
        }
        Spacer(modifier = Modifier.height(16.dp))
      }
    }
  }

  // Message Options Sheet (delete for everyone, copy)
  selectedMessageForMenu?.let { decMsg ->
    ModalBottomSheet(
      onDismissRequest = { selectedMessageForMenu = null }
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp)
      ) {
        Text("Message Options", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Spacer(modifier = Modifier.height(12.dp))

        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clickable {
              clipboardManager.setText(AnnotatedString(decMsg.decryptedText))
              selectedMessageForMenu = null
            }
            .padding(12.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text("Copy Text", fontWeight = FontWeight.Medium)
        }

        if (decMsg.message.senderId == currentUserId && !decMsg.message.deletedForEveryone) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clickable {
                viewModel.deleteForEveryone(decMsg.message.messageId)
                selectedMessageForMenu = null
              }
              .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(imageVector = Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error)
            Spacer(modifier = Modifier.width(12.dp))
            Text("Delete for everyone", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Medium)
          }
        }
        Spacer(modifier = Modifier.height(16.dp))
      }
    }
  }
}

@Composable
fun MessageBubble(
  decryptedMessage: DecryptedMessage,
  isFromMe: Boolean,
  senderProfile: com.example.data.model.UserProfile?,
  isGroup: Boolean,
  onLongClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  val timeFormat = remember { SimpleDateFormat("hh:mm a", Locale.getDefault()) }
  val timeString = decryptedMessage.message.createdAt?.toDate()?.let { timeFormat.format(it) } ?: ""

  Column(
    modifier = modifier.fillMaxWidth(),
    horizontalAlignment = if (isFromMe) Alignment.End else Alignment.Start
  ) {
    if (isGroup && !isFromMe && senderProfile != null) {
      Text(
        text = senderProfile.displayName.ifBlank { "@${senderProfile.username}" },
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 12.dp, bottom = 2.dp)
      )
    }

    Surface(
      shape = RoundedCornerShape(
        topStart = 16.dp,
        topEnd = 16.dp,
        bottomStart = if (isFromMe) 16.dp else 4.dp,
        bottomEnd = if (isFromMe) 4.dp else 16.dp
      ),
      color = if (isFromMe) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
      modifier = Modifier
        .widthIn(max = 280.dp)
        .clickable(onClick = onLongClick)
        .testTag("message_bubble_${decryptedMessage.message.messageId}")
    ) {
      Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
        if (decryptedMessage.message.messageType != "text") {
          // File / Image Attachment Card
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(bottom = 6.dp)
          ) {
            Icon(
              imageVector = if (decryptedMessage.message.messageType == "image") Icons.Default.Image else Icons.Default.Description,
              contentDescription = null,
              tint = if (isFromMe) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = decryptedMessage.message.fileName ?: "Encrypted File",
              fontWeight = FontWeight.SemiBold,
              style = MaterialTheme.typography.bodyMedium,
              color = if (isFromMe) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
            )
          }
        }

        Text(
          text = decryptedMessage.decryptedText,
          style = MaterialTheme.typography.bodyMedium,
          color = if (isFromMe) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(modifier = Modifier.height(4.dp))

        Row(
          modifier = Modifier.align(Alignment.End),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            imageVector = Icons.Default.Lock,
            contentDescription = null,
            tint = if (isFromMe) MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.7f)
            else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
            modifier = Modifier.size(10.dp)
          )
          Spacer(modifier = Modifier.width(3.dp))
          Text(
            text = timeString,
            fontSize = 10.sp,
            color = if (isFromMe) MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.7f)
            else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
          )
        }
      }
    }
  }
}
