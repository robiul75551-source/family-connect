package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Family Connect Premium Theme Palette
// Slate & Deep Emerald with Warm Champagne / Amber accents

val EmeraldPrimaryLight = Color(0xFF0D9488) // Rich Teal / Emerald
val EmeraldOnPrimaryLight = Color(0xFFFFFFFF)
val EmeraldPrimaryContainerLight = Color(0xFFCCFBF1)
val EmeraldOnPrimaryContainerLight = Color(0xFF115E59)

val AmberSecondaryLight = Color(0xFFD97706) // Warm Amber Gold
val AmberOnSecondaryLight = Color(0xFFFFFFFF)
val AmberSecondaryContainerLight = Color(0xFFFEF3C7)
val AmberOnSecondaryContainerLight = Color(0xFF92400E)

val BackgroundLight = Color(0xFFF8FAFC) // Slate 50
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val OnSurfaceLight = Color(0xFF0F172A)
val OnSurfaceVariantLight = Color(0xFF475569)
val OutlineLight = Color(0xFFCBD5E1)

// Dark Palette
val EmeraldPrimaryDark = Color(0xFF2DD4BF) // Bright Teal
val EmeraldOnPrimaryDark = Color(0xFF042F2E)
val EmeraldPrimaryContainerDark = Color(0xFF134E4A)
val EmeraldOnPrimaryContainerDark = Color(0xFF99F6E4)

val AmberSecondaryDark = Color(0xFFFBBF24) // Bright Amber
val AmberOnSecondaryDark = Color(0xFF451A03)
val AmberSecondaryContainerDark = Color(0xFF78350F)
val AmberOnSecondaryContainerDark = Color(0xFFFDE68A)

val BackgroundDark = Color(0xFF0B1120) // Deep Obsidian Slate
val SurfaceDark = Color(0xFF1E293B) // Slate 800
val SurfaceVariantDark = Color(0xFF334155) // Slate 700
val OnSurfaceDark = Color(0xFFF8FAFC)
val OnSurfaceVariantDark = Color(0xFF94A3B8)
val OutlineDark = Color(0xFF475569)

// Accent Status Colors
val OnlineGreen = Color(0xFF10B981)
val SecurityShieldBadge = Color(0xFF059669)
val BubbleSelfLight = Color(0xFF14B8A6)
val BubbleOtherLight = Color(0xFFF1F5F9)
val BubbleSelfDark = Color(0xFF0F766E)
val BubbleOtherDark = Color(0xFF1E293B)
