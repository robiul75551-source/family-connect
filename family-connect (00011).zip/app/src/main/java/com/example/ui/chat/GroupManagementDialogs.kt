package com.example.ui.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.Conversation
import com.example.data.model.UserProfile
import com.example.data.repository.UserRepository
import com.example.ui.common.UserAvatar
import kotlinx.coroutines.launch

@Composable
fun NewDirectChatDialog(
  userRepository: UserRepository,
  onUserSelected: (UserProfile) -> Unit,
  onDismiss: () -> Unit
) {
  var usernameQuery by remember { mutableStateOf("") }
  var isSearching by remember { mutableStateOf(false) }
  var foundUser by remember { mutableStateOf<UserProfile?>(null) }
  var searchError by remember { mutableStateOf<String?>(null) }
  val scope = rememberCoroutineScope()

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Text("Find Family Member", fontWeight = FontWeight.Bold)
    },
    text = {
      Column(modifier = Modifier.fillMaxWidth()) {
        Text(
          text = "Enter the exact unique @username. Phone numbers and emails are never exposed.",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(14.dp))

        OutlinedTextField(
          value = usernameQuery,
          onValueChange = {
            usernameQuery = it.lowercase().trim()
            foundUser = null
            searchError = null
          },
          label = { Text("Username") },
          prefix = { Text("@") },
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("search_user_dialog_input")
        )

        Spacer(modifier = Modifier.height(12.dp))

        Button(
          onClick = {
            if (usernameQuery.length >= 3) {
              isSearching = true
              searchError = null
              scope.launch {
                val res = userRepository.findUserByUsername(usernameQuery)
                isSearching = false
                if (res.isSuccess) {
                  val profile = res.getOrNull()
                  if (profile != null) {
                    foundUser = profile
                  } else {
                    searchError = "No user found with @$usernameQuery"
                  }
                } else {
                  searchError = res.exceptionOrNull()?.localizedMessage ?: "Search failed."
                }
              }
            } else {
              searchError = "Username must be at least 3 characters."
            }
          },
          modifier = Modifier.fillMaxWidth(),
          shape = RoundedCornerShape(10.dp)
        ) {
          if (isSearching) {
            CircularProgressIndicator(
              modifier = Modifier.size(18.dp),
              color = MaterialTheme.colorScheme.onPrimary,
              strokeWidth = 2.dp
            )
          } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(imageVector = Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("Search Username")
            }
          }
        }

        if (searchError != null) {
          Spacer(modifier = Modifier.height(8.dp))
          Text(text = searchError!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }

        foundUser?.let { user ->
          Spacer(modifier = Modifier.height(16.dp))
          Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              UserAvatar(name = user.displayName, seed = user.avatarSeed, size = 44.dp)
              Spacer(modifier = Modifier.width(12.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text(user.displayName, fontWeight = FontWeight.Bold)
                Text("@${user.username}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
              }
            }
          }
        }
      }
    },
    confirmButton = {
      if (foundUser != null) {
        Button(
          onClick = {
            onUserSelected(foundUser!!)
            onDismiss()
          },
          modifier = Modifier.testTag("start_chat_confirmed_button")
        ) {
          Text("Start Encrypted Chat")
        }
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) {
        Text("Cancel")
      }
    }
  )
}

@Composable
fun CreateGroupDialog(
  onCreateGroup: (name: String) -> Unit,
  onDismiss: () -> Unit
) {
  var groupName by remember { mutableStateOf("") }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Create Family Group", fontWeight = FontWeight.Bold) },
    text = {
      Column {
        Text(
          "Create a secure private space for your family members. A 6-digit invite code will be generated.",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(14.dp))
        OutlinedTextField(
          value = groupName,
          onValueChange = { groupName = it },
          label = { Text("Family Group Name") },
          placeholder = { Text("e.g. Khan Family") },
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("group_name_input")
        )
      }
    },
    confirmButton = {
      Button(
        onClick = {
          if (groupName.isNotBlank()) {
            onCreateGroup(groupName.trim())
            onDismiss()
          }
        },
        enabled = groupName.isNotBlank(),
        modifier = Modifier.testTag("confirm_create_group_button")
      ) {
        Text("Create Group")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("Cancel") }
    }
  )
}

@Composable
fun JoinGroupDialog(
  onJoin: (code: String) -> Unit,
  onDismiss: () -> Unit
) {
  var inviteCode by remember { mutableStateOf("") }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Join Family Group", fontWeight = FontWeight.Bold) },
    text = {
      Column {
        Text(
          "Enter the 6-digit invitation code provided by your family administrator.",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(modifier = Modifier.height(14.dp))
        OutlinedTextField(
          value = inviteCode,
          onValueChange = { inviteCode = it.filter { c -> c.isDigit() }.take(6) },
          label = { Text("6-Digit Code") },
          placeholder = { Text("123456") },
          singleLine = true,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("invite_code_input")
        )
      }
    },
    confirmButton = {
      Button(
        onClick = {
          if (inviteCode.length == 6) {
            onJoin(inviteCode)
            onDismiss()
          }
        },
        enabled = inviteCode.length == 6,
        modifier = Modifier.testTag("confirm_join_group_button")
      ) {
        Text("Join Group")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("Cancel") }
    }
  )
}

@Composable
fun GroupInfoDialog(
  conversation: Conversation,
  participantProfiles: Map<String, UserProfile>,
  onDismiss: () -> Unit
) {
  val clipboardManager = LocalClipboardManager.current
  var copiedNotice by remember { mutableStateOf(false) }

  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(imageVector = Icons.Default.Group, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.width(8.dp))
        Text(conversation.name, fontWeight = FontWeight.Bold)
      }
    },
    text = {
      Column(modifier = Modifier.fillMaxWidth()) {
        if (conversation.inviteCode.isNotBlank()) {
          Surface(
            shape = RoundedCornerShape(10.dp),
            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.padding(12.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Column {
                Text("Family Invite Code", style = MaterialTheme.typography.labelSmall)
                Text(
                  text = conversation.inviteCode,
                  style = MaterialTheme.typography.titleLarge,
                  fontWeight = FontWeight.Bold,
                  color = MaterialTheme.colorScheme.primary
                )
              }
              IconButton(
                onClick = {
                  clipboardManager.setText(AnnotatedString(conversation.inviteCode))
                  copiedNotice = true
                }
              ) {
                Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy Code")
              }
            }
          }
          if (copiedNotice) {
            Text(
              "Invite code copied to clipboard!",
              style = MaterialTheme.typography.labelSmall,
              color = MaterialTheme.colorScheme.primary,
              modifier = Modifier.padding(top = 4.dp)
            )
          }
          Spacer(modifier = Modifier.height(14.dp))
        }

        Text(
          "Members (${conversation.participantUids.size})",
          fontWeight = FontWeight.SemiBold,
          style = MaterialTheme.typography.titleSmall
        )
        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(modifier = Modifier.height(180.dp)) {
          items(conversation.participantUids) { uid ->
            val profile = participantProfiles[uid]
            val isAdmin = conversation.adminUids.contains(uid)

            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 6.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              UserAvatar(
                name = profile?.displayName ?: "Member",
                seed = profile?.avatarSeed ?: uid,
                size = 32.dp
              )
              Spacer(modifier = Modifier.width(10.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text(profile?.displayName ?: "Family Member", fontWeight = FontWeight.Medium)
                Text(
                  if (profile != null) "@${profile.username}" else "Active Member",
                  style = MaterialTheme.typography.labelSmall,
                  color = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
              if (isAdmin) {
                Surface(
                  shape = RoundedCornerShape(6.dp),
                  color = MaterialTheme.colorScheme.primaryContainer
                ) {
                  Text(
                    "Admin",
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                  )
                }
              }
            }
          }
        }
      }
    },
    confirmButton = {
      Button(onClick = onDismiss) { Text("Close") }
    }
  )
}
