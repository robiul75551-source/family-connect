package com.example.ui.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.crypto.CryptoManager
import com.example.data.model.PrivateUserInfo
import com.example.data.model.UserProfile
import com.example.data.repository.UserRepository
import com.example.ui.auth.AuthViewModel
import com.example.ui.common.AvatarPalette
import com.example.ui.common.E2eeSecurityBadge
import com.example.ui.common.UserAvatar
import com.example.ui.theme.SecurityShieldBadge
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
  userRepository: UserRepository,
  authViewModel: AuthViewModel,
  onSignedOut: () -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val userProfile by authViewModel.userProfile.collectAsState()
  val privateInfo by authViewModel.privateInfo.collectAsState()

  var showEditNameDialog by remember { mutableStateOf(false) }
  var showAvatarDialog by remember { mutableStateOf(false) }
  var showPinDialog by remember { mutableStateOf(false) }
  var showPhoneDialog by remember { mutableStateOf(false) }
  var showPrivacyInfoDialog by remember { mutableStateOf(false) }

  Scaffold(
    topBar = {
      TopAppBar(
        title = { Text("Profile & Security", fontWeight = FontWeight.Bold) },
        actions = {
          IconButton(
            onClick = { showPrivacyInfoDialog = true },
            modifier = Modifier.testTag("privacy_info_button")
          ) {
            Icon(imageVector = Icons.Default.Info, contentDescription = "Privacy Info")
          }
        },
        colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
      )
    },
    modifier = modifier.testTag("profile_screen")
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
        .background(MaterialTheme.colorScheme.background)
        .verticalScroll(rememberScrollState())
        .padding(16.dp)
    ) {
      // Header Card
      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(20.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Box(contentAlignment = Alignment.BottomEnd) {
            UserAvatar(
              name = userProfile?.displayName ?: "User",
              seed = userProfile?.avatarSeed ?: "1",
              size = 80.dp
            )
            Box(
              modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primary)
                .clickable { showAvatarDialog = true },
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.Edit,
                contentDescription = "Edit Avatar",
                tint = MaterialTheme.colorScheme.onPrimary,
                modifier = Modifier.size(14.dp)
              )
            }
          }

          Spacer(modifier = Modifier.height(12.dp))

          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = userProfile?.displayName ?: "Family User",
              style = MaterialTheme.typography.titleLarge,
              fontWeight = FontWeight.Bold
            )
            IconButton(
              onClick = { showEditNameDialog = true },
              modifier = Modifier.size(32.dp)
            ) {
              Icon(
                imageVector = Icons.Default.Edit,
                contentDescription = "Edit name",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(16.dp)
              )
            }
          }

          Text(
            text = "@${userProfile?.username ?: ""}",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.primary,
            fontWeight = FontWeight.SemiBold
          )

          Spacer(modifier = Modifier.height(8.dp))
          E2eeSecurityBadge()
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      // Section: Privacy Settings
      Text(
        text = "PRIVACY PREFERENCES",
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(start = 4.dp, bottom = 6.dp)
      )

      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          // Online status visibility
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text("Online Status Privacy", fontWeight = FontWeight.SemiBold)
              Text(
                "Who can see when you are active: ${privateInfo?.onlineStatusPrivacy ?: "everyone"}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }

          Spacer(modifier = Modifier.height(8.dp))
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            val currentPrivacy = privateInfo?.onlineStatusPrivacy ?: "everyone"
            listOf("everyone" to "Everyone", "contacts" to "Contacts Only", "nobody" to "Nobody").forEach { (key, label) ->
              Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (currentPrivacy == key) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier
                  .weight(1f)
                  .clickable {
                    scope.launch {
                      userRepository.updatePrivacySettings(
                        onlineStatusPrivacy = key,
                        readReceiptsEnabled = privateInfo?.readReceiptsEnabled ?: true
                      )
                    }
                  }
                  .padding(vertical = 8.dp),
                contentColor = if (currentPrivacy == key) MaterialTheme.colorScheme.onPrimaryContainer else MaterialTheme.colorScheme.onSurfaceVariant
              ) {
                Text(
                  text = label,
                  style = MaterialTheme.typography.labelSmall,
                  fontWeight = FontWeight.Medium,
                  textAlign = TextAlign.Center
                )
              }
            }
          }

          HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

          // Read Receipts
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text("Read Receipts", fontWeight = FontWeight.SemiBold)
              Text(
                "Show delivered and read status for messages",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
            Switch(
              checked = privateInfo?.readReceiptsEnabled ?: true,
              onCheckedChange = { checked ->
                scope.launch {
                  userRepository.updatePrivacySettings(
                    onlineStatusPrivacy = privateInfo?.onlineStatusPrivacy ?: "everyone",
                    readReceiptsEnabled = checked
                  )
                }
              }
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      // Section: App Lock & Security
      Text(
        text = "DEVICE APP LOCK",
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(start = 4.dp, bottom = 6.dp)
      )

      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          val isLockEnabled = privateInfo?.appLockEnabled == true
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column(modifier = Modifier.weight(1f)) {
              Text("4-Digit Security PIN", fontWeight = FontWeight.SemiBold)
              Text(
                if (isLockEnabled) "App lock active on launch" else "Protect app launch with a secure PIN",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
            Switch(
              checked = isLockEnabled,
              onCheckedChange = { enabled ->
                if (enabled) {
                  showPinDialog = true
                } else {
                  scope.launch { userRepository.disableAppLock() }
                }
              }
            )
          }

          if (isLockEnabled) {
            Spacer(modifier = Modifier.height(8.dp))
            TextButton(onClick = { showPinDialog = true }) {
              Text("Change App Lock PIN")
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      // Section: Protected Private Records
      Text(
        text = "PROTECTED PRIVATE PROFILE",
        style = MaterialTheme.typography.labelSmall,
        fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(start = 4.dp, bottom = 6.dp)
      )

      Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Column {
              Text("Phone Number", style = MaterialTheme.typography.labelMedium)
              Text(
                text = privateInfo?.phone?.ifBlank { "Not provided" } ?: "Not provided",
                fontWeight = FontWeight.SemiBold,
                style = MaterialTheme.typography.bodyMedium
              )
            }
            IconButton(onClick = { showPhoneDialog = true }) {
              Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit phone", tint = MaterialTheme.colorScheme.primary)
            }
          }

          HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

          Column {
            Text("Verified Account Email", style = MaterialTheme.typography.labelMedium)
            Text(
              text = privateInfo?.email?.ifBlank { "Google Account" } ?: "Google Account",
              fontWeight = FontWeight.SemiBold,
              style = MaterialTheme.typography.bodyMedium
            )
          }

          Spacer(modifier = Modifier.height(10.dp))

          Surface(
            shape = RoundedCornerShape(8.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            modifier = Modifier.fillMaxWidth()
          ) {
            Row(
              modifier = Modifier.padding(10.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Icon(
                imageVector = Icons.Default.Security,
                contentDescription = null,
                tint = SecurityShieldBadge,
                modifier = Modifier.size(16.dp)
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                "Phone and email are stored in /users/{uid}/private/info, accessible strictly by you. Zero-trust rules reject reads from all other callers.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(24.dp))

      // Sign Out Button
      Button(
        onClick = {
          authViewModel.signOut(context, onSignedOut)
        },
        modifier = Modifier
          .fillMaxWidth()
          .height(48.dp)
          .testTag("sign_out_button"),
        shape = RoundedCornerShape(12.dp)
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(imageVector = Icons.AutoMirrored.Filled.ExitToApp, contentDescription = null)
          Spacer(modifier = Modifier.width(8.dp))
          Text("Sign Out of Family Connect")
        }
      }
    }
  }

  // Edit Display Name Dialog
  if (showEditNameDialog) {
    var newName by remember { mutableStateOf(userProfile?.displayName ?: "") }
    AlertDialog(
      onDismissRequest = { showEditNameDialog = false },
      title = { Text("Edit Display Name") },
      text = {
        OutlinedTextField(
          value = newName,
          onValueChange = { newName = it },
          label = { Text("Display Name") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )
      },
      confirmButton = {
        Button(
          onClick = {
            if (newName.isNotBlank()) {
              scope.launch { userRepository.updateDisplayName(newName) }
              showEditNameDialog = false
            }
          }
        ) {
          Text("Save")
        }
      },
      dismissButton = {
        TextButton(onClick = { showEditNameDialog = false }) { Text("Cancel") }
      }
    )
  }

  // Change Avatar Accent Dialog
  if (showAvatarDialog) {
    AlertDialog(
      onDismissRequest = { showAvatarDialog = false },
      title = { Text("Select Avatar Accent") },
      text = {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceEvenly
        ) {
          AvatarPalette.indices.forEach { index ->
            val seed = (index + 1).toString()
            Box(
              modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(AvatarPalette[index])
                .clickable {
                  scope.launch { userRepository.updateAvatarSeed(seed) }
                  showAvatarDialog = false
                },
              contentAlignment = Alignment.Center
            ) {
              if (userProfile?.avatarSeed == seed) {
                Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = Color.White)
              }
            }
          }
        }
      },
      confirmButton = {
        TextButton(onClick = { showAvatarDialog = false }) { Text("Close") }
      }
    )
  }

  // App Lock PIN Setup Dialog
  if (showPinDialog) {
    var pin by remember { mutableStateOf("") }
    var pinConfirm by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf<String?>(null) }

    AlertDialog(
      onDismissRequest = { showPinDialog = false },
      title = { Text("Set 4-Digit App Lock PIN") },
      text = {
        Column {
          Text(
            "Enter a 4-digit PIN. This PIN is hashed locally with salt and verified on your device when opening the app.",
            style = MaterialTheme.typography.bodySmall
          )
          Spacer(modifier = Modifier.height(12.dp))
          OutlinedTextField(
            value = pin,
            onValueChange = { pin = it.filter { c -> c.isDigit() }.take(4) },
            label = { Text("New PIN (4 digits)") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
          Spacer(modifier = Modifier.height(8.dp))
          OutlinedTextField(
            value = pinConfirm,
            onValueChange = { pinConfirm = it.filter { c -> c.isDigit() }.take(4) },
            label = { Text("Confirm PIN") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
          if (pinError != null) {
            Spacer(modifier = Modifier.height(6.dp))
            Text(pinError!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
          }
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (pin.length != 4) {
              pinError = "PIN must be exactly 4 digits."
              return@Button
            }
            if (pin != pinConfirm) {
              pinError = "PINs do not match."
              return@Button
            }
            scope.launch {
              userRepository.setAppLockPin(pin)
              showPinDialog = false
            }
          }
        ) {
          Text("Set PIN")
        }
      },
      dismissButton = {
        TextButton(onClick = { showPinDialog = false }) { Text("Cancel") }
      }
    )
  }

  // Edit Phone Dialog
  if (showPhoneDialog) {
    var phoneInput by remember { mutableStateOf(privateInfo?.phone?.removePrefix("+880") ?: "") }
    AlertDialog(
      onDismissRequest = { showPhoneDialog = false },
      title = { Text("Update Private Phone") },
      text = {
        Column {
          Text("Bangladesh (+880) phone numbers. Kept isolated from public queries.", style = MaterialTheme.typography.bodySmall)
          Spacer(modifier = Modifier.height(10.dp))
          OutlinedTextField(
            value = phoneInput,
            onValueChange = { phoneInput = it.filter { c -> c.isDigit() } },
            label = { Text("Phone Number") },
            prefix = { Text("+880 ") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            val full = if (phoneInput.isNotBlank()) "+880$phoneInput" else ""
            scope.launch {
              userRepository.updatePrivatePhoneEmail(full, privateInfo?.email ?: "")
              showPhoneDialog = false
            }
          }
        ) {
          Text("Update")
        }
      },
      dismissButton = {
        TextButton(onClick = { showPhoneDialog = false }) { Text("Cancel") }
      }
    )
  }

  // Security & Cryptography Info Dialog
  if (showPrivacyInfoDialog) {
    AlertDialog(
      onDismissRequest = { showPrivacyInfoDialog = false },
      title = {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
          Spacer(modifier = Modifier.width(8.dp))
          Text("Security & Privacy Architecture", fontWeight = FontWeight.Bold)
        }
      },
      text = {
        Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
          Text("1. End-to-End Encryption (E2EE)", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
          Text(
            "Every message and shared file is encrypted on your device using standard AES-256-GCM. Decryption keys are derived directly between devices using Elliptic Curve Diffie-Hellman (ECDH P-256). Private keys never leave your phone.",
            style = MaterialTheme.typography.bodySmall
          )

          Spacer(modifier = Modifier.height(10.dp))
          Text("2. Guaranteed Phone & Email Privacy", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
          Text(
            "Phone numbers and emails are segregated into an isolated subcollection (/users/{uid}/private/info). Zero-trust Firestore Security Rules block reads by any user other than yourself. Public discovery functions strictly through your unique @username.",
            style = MaterialTheme.typography.bodySmall
          )

          Spacer(modifier = Modifier.height(10.dp))
          Text("3. Family Groups & Access Control", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
          Text(
            "Group conversations are protected by secure invite codes and per-recipient key wrapping envelopes. Only verified group participants have access to message payloads.",
            style = MaterialTheme.typography.bodySmall
          )
        }
      },
      confirmButton = {
        Button(onClick = { showPrivacyInfoDialog = false }) { Text("Got it") }
      }
    )
  }
}
