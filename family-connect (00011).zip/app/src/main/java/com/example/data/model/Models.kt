package com.example.data.model

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentId
import com.google.firebase.firestore.IgnoreExtraProperties
import com.google.firebase.firestore.ServerTimestamp

@IgnoreExtraProperties
data class UserProfile(
  @DocumentId val id: String = "",
  val userId: String = "",
  val username: String = "",
  val displayName: String = "",
  val photoUrl: String? = null,
  val avatarSeed: String = "1",
  val isOnline: Boolean = false,
  val lastSeen: Timestamp? = null,
  val publicKey: String = "",
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class PrivateUserInfo(
  @DocumentId val id: String = "",
  val userId: String = "",
  val phone: String = "",
  val email: String = "",
  val pinHash: String = "",
  val pinSalt: String = "",
  val appLockEnabled: Boolean = false,
  val onlineStatusPrivacy: String = "everyone", // "everyone", "contacts", "nobody"
  val readReceiptsEnabled: Boolean = true,
  @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class UsernameReservation(
  @DocumentId val id: String = "",
  val username: String = "",
  val userId: String = "",
  @ServerTimestamp val createdAt: Timestamp? = null
)

@IgnoreExtraProperties
data class UserContact(
  @DocumentId val id: String = "",
  val contactUserId: String = "",
  val username: String = "",
  val displayName: String = "",
  @ServerTimestamp val addedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class BlockedContact(
  @DocumentId val id: String = "",
  val blockedUserId: String = "",
  val username: String = "",
  @ServerTimestamp val blockedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class Conversation(
  @DocumentId val id: String = "",
  val conversationId: String = "",
  val type: String = "direct", // "direct" or "group"
  val participantUids: List<String> = emptyList(),
  val adminUids: List<String> = emptyList(),
  val name: String = "",
  val photoUrl: String? = null,
  val inviteCode: String = "",
  val inviteExpiresAt: Timestamp? = null,
  val lastMessageTextEncrypted: String = "",
  val lastMessageTimestamp: Timestamp? = null,
  val lastMessageSenderId: String = "",
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null
)

@IgnoreExtraProperties
data class ChatMessage(
  @DocumentId val id: String = "",
  val messageId: String = "",
  val conversationId: String = "",
  val senderId: String = "",
  val participantUids: List<String> = emptyList(),
  val ciphertext: String = "",
  val iv: String = "",
  val messageType: String = "text", // "text", "image", "file"
  val fileName: String? = null,
  val fileSize: Long = 0L,
  val fileMimeType: String? = null,
  val encryptedKeyMap: String? = null, // JSON map of recipientUid -> wrapped key
  val deletedForEveryone: Boolean = false,
  @ServerTimestamp val createdAt: Timestamp? = null,
  @ServerTimestamp val updatedAt: Timestamp? = null
)
