package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.crypto.CryptoManager
import com.example.data.OperationType
import com.example.data.handleFirestoreError
import com.example.data.model.BlockedContact
import com.example.data.model.PrivateUserInfo
import com.example.data.model.UserContact
import com.example.data.model.UserProfile
import com.example.data.model.UsernameReservation
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class UserRepository(private val db: FirebaseFirestore, private val context: Context) {

  constructor(context: Context) : this(
    FirebaseFirestore.getInstance(
      context.applicationContext.getString(R.string.firestore_database_id)
    ),
    context.applicationContext
  )

  private val auth = Firebase.auth

  fun requireUserId(): String {
    return auth.currentUser?.uid
      ?: throw IllegalStateException("User must be signed in before accessing user repository.")
  }

  fun observeUserProfile(userId: String): Flow<UserProfile?> = flow {
    val path = "users/$userId"
    emitAll(
      db.collection("users").document(userId)
        .snapshots()
        .map { it.toObject(UserProfile::class.java) }
        .catch { e ->
          if (e is Exception) handleFirestoreError(e, OperationType.GET, path)
          throw e
        }
    )
  }

  fun observePrivateInfo(userId: String): Flow<PrivateUserInfo?> = flow {
    val path = "users/$userId/private/info"
    emitAll(
      db.collection("users").document(userId).collection("private").document("info")
        .snapshots()
        .map { it.toObject(PrivateUserInfo::class.java) }
        .catch { e ->
          if (e is Exception) handleFirestoreError(e, OperationType.GET, path)
          throw e
        }
    )
  }

  suspend fun registerUserProfile(
    username: String,
    displayName: String,
    avatarSeed: String,
    phone: String = "",
    email: String = ""
  ): Result<Unit> {
    val uid = requireUserId()
    val cleanUsername = username.trim().lowercase()
    val publicKeyBase64 = CryptoManager.getDevicePublicKeyBase64(context)

    return try {
      val userRef = db.collection("users").document(uid)
      val usernameRef = db.collection("usernames").document(cleanUsername)
      val privateRef = userRef.collection("private").document("info")

      // Use a Firestore transaction or batch to ensure atomic username reservation
      db.runTransaction { transaction ->
        val usernameDoc = transaction.get(usernameRef)
        if (usernameDoc.exists() && usernameDoc.getString("userId") != uid) {
          throw IllegalArgumentException("Username @$cleanUsername is already taken. Please choose another.")
        }

        val publicPayload = hashMapOf<String, Any>(
          "userId" to uid,
          "username" to cleanUsername,
          "displayName" to displayName.trim(),
          "avatarSeed" to avatarSeed,
          "isOnline" to true,
          "publicKey" to publicKeyBase64,
          "createdAt" to FieldValue.serverTimestamp(),
          "updatedAt" to FieldValue.serverTimestamp()
        )

        val usernamePayload = hashMapOf<String, Any>(
          "username" to cleanUsername,
          "userId" to uid,
          "createdAt" to FieldValue.serverTimestamp()
        )

        val privatePayload = hashMapOf<String, Any>(
          "userId" to uid,
          "phone" to phone.trim(),
          "email" to email.trim(),
          "appLockEnabled" to false,
          "onlineStatusPrivacy" to "everyone",
          "readReceiptsEnabled" to true,
          "updatedAt" to FieldValue.serverTimestamp()
        )

        transaction.set(userRef, publicPayload)
        transaction.set(usernameRef, usernamePayload)
        transaction.set(privateRef, privatePayload)
      }.await()

      Result.success(Unit)
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, "users/$uid")
      Result.failure(e)
    }
  }

  suspend fun updateDisplayName(newDisplayName: String): Result<Unit> {
    val uid = requireUserId()
    val docRef = db.collection("users").document(uid)
    return try {
      docRef.update(
        mapOf(
          "displayName" to newDisplayName.trim(),
          "updatedAt" to FieldValue.serverTimestamp()
        )
      ).await()
      Result.success(Unit)
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
      Result.failure(e)
    }
  }

  suspend fun updateAvatarSeed(newSeed: String): Result<Unit> {
    val uid = requireUserId()
    val docRef = db.collection("users").document(uid)
    return try {
      docRef.update(
        mapOf(
          "avatarSeed" to newSeed,
          "updatedAt" to FieldValue.serverTimestamp()
        )
      ).await()
      Result.success(Unit)
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
      Result.failure(e)
    }
  }

  suspend fun setOnlineStatus(isOnline: Boolean) {
    val uid = auth.currentUser?.uid ?: return
    val docRef = db.collection("users").document(uid)
    try {
      docRef.update(
        mapOf(
          "isOnline" to isOnline,
          "lastSeen" to FieldValue.serverTimestamp(),
          "updatedAt" to FieldValue.serverTimestamp()
        )
      ).await()
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
    }
  }

  suspend fun updatePrivacySettings(
    onlineStatusPrivacy: String,
    readReceiptsEnabled: Boolean
  ): Result<Unit> {
    val uid = requireUserId()
    val docRef = db.collection("users").document(uid).collection("private").document("info")
    return try {
      docRef.update(
        mapOf(
          "onlineStatusPrivacy" to onlineStatusPrivacy,
          "readReceiptsEnabled" to readReceiptsEnabled,
          "updatedAt" to FieldValue.serverTimestamp()
        )
      ).await()
      Result.success(Unit)
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
      Result.failure(e)
    }
  }

  suspend fun updatePrivatePhoneEmail(phone: String, email: String): Result<Unit> {
    val uid = requireUserId()
    val docRef = db.collection("users").document(uid).collection("private").document("info")
    return try {
      docRef.update(
        mapOf(
          "phone" to phone.trim(),
          "email" to email.trim(),
          "updatedAt" to FieldValue.serverTimestamp()
        )
      ).await()
      Result.success(Unit)
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
      Result.failure(e)
    }
  }

  suspend fun setAppLockPin(pin: String): Result<Unit> {
    val uid = requireUserId()
    val salt = CryptoManager.generateSalt()
    val hash = CryptoManager.hashPin(pin, salt)
    val docRef = db.collection("users").document(uid).collection("private").document("info")
    return try {
      docRef.update(
        mapOf(
          "pinHash" to hash,
          "pinSalt" to salt,
          "appLockEnabled" to true,
          "updatedAt" to FieldValue.serverTimestamp()
        )
      ).await()
      Result.success(Unit)
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
      Result.failure(e)
    }
  }

  suspend fun disableAppLock(): Result<Unit> {
    val uid = requireUserId()
    val docRef = db.collection("users").document(uid).collection("private").document("info")
    return try {
      docRef.update(
        mapOf(
          "appLockEnabled" to false,
          "updatedAt" to FieldValue.serverTimestamp()
        )
      ).await()
      Result.success(Unit)
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, docRef.path)
      Result.failure(e)
    }
  }

  /**
   * Privacy-Preserving Username Search:
   * First looks up username registry doc (/usernames/{username})
   * If found, fetches the public profile (/users/{userId}).
   * Strictly never exposes phone or email!
   */
  suspend fun findUserByUsername(username: String): Result<UserProfile?> {
    val clean = username.trim().lowercase().removePrefix("@")
    val usernameRef = db.collection("usernames").document(clean)
    return try {
      val doc = usernameRef.get().await()
      if (!doc.exists()) {
        return Result.success(null)
      }
      val targetUid = doc.getString("userId") ?: return Result.success(null)
      val userDoc = db.collection("users").document(targetUid).get().await()
      val profile = userDoc.toObject(UserProfile::class.java)
      Result.success(profile)
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.GET, usernameRef.path)
      Result.failure(e)
    }
  }

  fun observeContacts(): Flow<List<UserContact>> = flow {
    val uid = requireUserId()
    val path = "users/$uid/contacts"
    emitAll(
      db.collection("users").document(uid).collection("contacts")
        .snapshots()
        .map { it.toObjects(UserContact::class.java) }
        .catch { e ->
          if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
          throw e
        }
    )
  }

  suspend fun addContact(targetUser: UserProfile): Result<Unit> {
    val uid = requireUserId()
    val docRef = db.collection("users").document(uid).collection("contacts").document(targetUser.userId)
    return try {
      val payload = hashMapOf<String, Any>(
        "contactUserId" to targetUser.userId,
        "username" to targetUser.username,
        "displayName" to targetUser.displayName,
        "addedAt" to FieldValue.serverTimestamp()
      )
      docRef.set(payload).await()
      Result.success(Unit)
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, docRef.path)
      Result.failure(e)
    }
  }

  suspend fun removeContact(targetUid: String): Result<Unit> {
    val uid = requireUserId()
    val docRef = db.collection("users").document(uid).collection("contacts").document(targetUid)
    return try {
      docRef.delete().await()
      Result.success(Unit)
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.DELETE, docRef.path)
      Result.failure(e)
    }
  }

  fun observeBlocked(): Flow<List<BlockedContact>> = flow {
    val uid = requireUserId()
    val path = "users/$uid/blocked"
    emitAll(
      db.collection("users").document(uid).collection("blocked")
        .snapshots()
        .map { it.toObjects(BlockedContact::class.java) }
        .catch { e ->
          if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
          throw e
        }
    )
  }

  suspend fun blockUser(targetUid: String, username: String): Result<Unit> {
    val uid = requireUserId()
    val docRef = db.collection("users").document(uid).collection("blocked").document(targetUid)
    return try {
      val payload = hashMapOf<String, Any>(
        "blockedUserId" to targetUid,
        "username" to username,
        "blockedAt" to FieldValue.serverTimestamp()
      )
      docRef.set(payload).await()
      Result.success(Unit)
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, docRef.path)
      Result.failure(e)
    }
  }

  suspend fun unblockUser(targetUid: String): Result<Unit> {
    val uid = requireUserId()
    val docRef = db.collection("users").document(uid).collection("blocked").document(targetUid)
    return try {
      docRef.delete().await()
      Result.success(Unit)
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.DELETE, docRef.path)
      Result.failure(e)
    }
  }
}
