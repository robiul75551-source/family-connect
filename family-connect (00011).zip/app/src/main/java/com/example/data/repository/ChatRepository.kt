package com.example.data.repository

import android.content.Context
import com.example.R
import com.example.crypto.CryptoManager
import com.example.data.OperationType
import com.example.data.handleFirestoreError
import com.example.data.model.ChatMessage
import com.example.data.model.Conversation
import com.example.data.model.UserProfile
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.util.Date
import java.util.UUID

class ChatRepository(private val db: FirebaseFirestore, private val context: Context) {

  constructor(context: Context) : this(
    FirebaseFirestore.getInstance(
      context.applicationContext.getString(R.string.firestore_database_id)
    ),
    context.applicationContext
  )

  private val auth = Firebase.auth

  fun requireUserId(): String {
    return auth.currentUser?.uid
      ?: throw IllegalStateException("User must be signed in before accessing chat repository.")
  }

  fun observeConversations(): Flow<List<Conversation>> = flow {
    val uid = requireUserId()
    val path = "conversations"
    emitAll(
      db.collection(path)
        .whereArrayContains("participantUids", uid)
        .snapshots()
        .map { snapshot ->
          snapshot.toObjects(Conversation::class.java).sortedByDescending {
            it.lastMessageTimestamp?.toDate()?.time ?: it.createdAt?.toDate()?.time ?: 0L
          }
        }
        .catch { e ->
          if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
          throw e
        }
    )
  }

  fun observeConversation(conversationId: String): Flow<Conversation?> = flow {
    val path = "conversations/$conversationId"
    emitAll(
      db.collection("conversations").document(conversationId)
        .snapshots()
        .map { it.toObject(Conversation::class.java) }
        .catch { e ->
          if (e is Exception) handleFirestoreError(e, OperationType.GET, path)
          throw e
        }
    )
  }

  fun observeMessages(conversationId: String): Flow<List<ChatMessage>> = flow {
    val path = "conversations/$conversationId/messages"
    emitAll(
      db.collection("conversations").document(conversationId).collection("messages")
        .orderBy("createdAt", Query.Direction.ASCENDING)
        .snapshots()
        .map { it.toObjects(ChatMessage::class.java) }
        .catch { e ->
          if (e is Exception) handleFirestoreError(e, OperationType.LIST, path)
          throw e
        }
    )
  }

  suspend fun getOrCreateDirectConversation(targetUser: UserProfile): Result<Conversation> {
    val uid = requireUserId()
    val convId = if (uid < targetUser.userId) "direct_${uid}_${targetUser.userId}" else "direct_${targetUser.userId}_${uid}"
    val docRef = db.collection("conversations").document(convId)

    return try {
      val existing = try { docRef.get().await() } catch (e: Exception) { null }
      if (existing != null && existing.exists()) {
        val conv = existing.toObject(Conversation::class.java)!!
        return Result.success(conv)
      }

      val newConv = hashMapOf<String, Any>(
        "conversationId" to convId,
        "type" to "direct",
        "participantUids" to listOf(uid, targetUser.userId),
        "adminUids" to listOf(uid, targetUser.userId),
        "name" to targetUser.displayName,
        "photoUrl" to (targetUser.photoUrl ?: ""),
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
      )
      docRef.set(newConv).await()

      val created = Conversation(
        conversationId = convId,
        type = "direct",
        participantUids = listOf(uid, targetUser.userId),
        adminUids = listOf(uid, targetUser.userId),
        name = targetUser.displayName,
        photoUrl = targetUser.photoUrl
      )
      Result.success(created)
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, docRef.path)
      Result.failure(e)
    }
  }

  suspend fun createFamilyGroup(name: String, initialMemberUids: List<String>): Result<Conversation> {
    val uid = requireUserId()
    val convId = "group_${UUID.randomUUID().toString().replace("-", "").take(16)}"
    val docRef = db.collection("conversations").document(convId)

    val allMembers = (initialMemberUids + uid).distinct()
    val inviteCode = (100000..999999).random().toString()
    // 7 days expiration for invite code
    val expiresAt = Timestamp(Date(System.currentTimeMillis() + 7 * 24 * 3600 * 1000L))

    return try {
      val payload = hashMapOf<String, Any>(
        "conversationId" to convId,
        "type" to "group",
        "participantUids" to allMembers,
        "adminUids" to listOf(uid),
        "name" to name.trim(),
        "inviteCode" to inviteCode,
        "inviteExpiresAt" to expiresAt,
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
      )
      docRef.set(payload).await()
      val created = docRef.get().await().toObject(Conversation::class.java)!!
      Result.success(created)
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.WRITE, docRef.path)
      Result.failure(e)
    }
  }

  suspend fun joinGroupByInviteCode(inviteCode: String): Result<Conversation> {
    val uid = requireUserId()
    val cleanCode = inviteCode.trim()

    return try {
      val query = db.collection("conversations")
        .whereEqualTo("type", "group")
        .whereEqualTo("inviteCode", cleanCode)
        .get()
        .await()

      if (query.isEmpty) {
        return Result.failure(IllegalArgumentException("Invalid or expired invite code."))
      }

      val groupDoc = query.documents.first()
      val conv = groupDoc.toObject(Conversation::class.java)
        ?: return Result.failure(IllegalStateException("Group format invalid."))

      val expires = conv.inviteExpiresAt?.toDate()?.time ?: 0L
      if (expires < System.currentTimeMillis()) {
        return Result.failure(IllegalArgumentException("This family invitation code has expired."))
      }

      if (!conv.participantUids.contains(uid)) {
        val updatedMembers = conv.participantUids + uid
        groupDoc.reference.update(
          mapOf(
            "participantUids" to updatedMembers,
            "updatedAt" to FieldValue.serverTimestamp()
          )
        ).await()
      }

      Result.success(conv.copy(participantUids = (conv.participantUids + uid).distinct()))
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.LIST, "conversations")
      Result.failure(e)
    }
  }

  /**
   * End-to-End Encrypted Message Transmission:
   * Direct Chat: Uses ECDH shared key between sender and recipient.
   * Group Chat: Uses symmetric group key encrypted individually for each member.
   */
  suspend fun sendEncryptedMessage(
    conversation: Conversation,
    plaintext: String,
    targetUserPublicKeyBase64: String? = null,
    groupMembersPublicKeys: Map<String, String> = emptyMap(),
    messageType: String = "text",
    fileName: String? = null,
    fileSize: Long = 0L
  ): Result<Unit> {
    val uid = requireUserId()
    val keyPair = CryptoManager.getOrCreateDeviceKeyPair(context)
    val msgId = "msg_${UUID.randomUUID().toString().replace("-", "").take(16)}"
    val msgRef = db.collection("conversations").document(conversation.conversationId)
      .collection("messages").document(msgId)

    return try {
      val ciphertextBase64: String
      val ivBase64: String
      var encryptedKeyMapJson: String? = null

      if (conversation.type == "direct") {
        require(!targetUserPublicKeyBase64.isNullOrBlank()) { "Recipient public key required for direct chat encryption." }
        val sharedKey = CryptoManager.deriveSharedSecret(keyPair.private, targetUserPublicKeyBase64)
        val (c, iv) = CryptoManager.encryptAesGcm(plaintext, sharedKey)
        ciphertextBase64 = c
        ivBase64 = iv
      } else {
        // Family Group Chat
        val groupKey = CryptoManager.generateGroupSymmetricKey()
        val (c, iv) = CryptoManager.encryptAesGcm(plaintext, groupKey)
        ciphertextBase64 = c
        ivBase64 = iv
        encryptedKeyMapJson = CryptoManager.buildEncryptedKeyMap(
          groupKey = groupKey,
          participantsPublicKeys = groupMembersPublicKeys,
          localPrivateKey = keyPair.private
        )
      }

      val payload = hashMapOf<String, Any>(
        "messageId" to msgId,
        "conversationId" to conversation.conversationId,
        "senderId" to uid,
        "participantUids" to conversation.participantUids,
        "ciphertext" to ciphertextBase64,
        "iv" to ivBase64,
        "messageType" to messageType,
        "deletedForEveryone" to false,
        "createdAt" to FieldValue.serverTimestamp(),
        "updatedAt" to FieldValue.serverTimestamp()
      )

      if (fileName != null) payload["fileName"] = fileName
      if (fileSize > 0) payload["fileSize"] = fileSize
      if (encryptedKeyMapJson != null) payload["encryptedKeyMap"] = encryptedKeyMapJson

      msgRef.set(payload).await()

      // Update conversation last message preview
      val convRef = db.collection("conversations").document(conversation.conversationId)
      convRef.update(
        mapOf(
          "lastMessageTextEncrypted" to if (messageType == "text") "[Encrypted Message]" else "[Encrypted File]",
          "lastMessageTimestamp" to FieldValue.serverTimestamp(),
          "lastMessageSenderId" to uid,
          "updatedAt" to FieldValue.serverTimestamp()
        )
      ).await()

      Result.success(Unit)
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.CREATE, msgRef.path)
      Result.failure(e)
    }
  }

  suspend fun deleteMessageForEveryone(conversationId: String, messageId: String): Result<Unit> {
    val uid = requireUserId()
    val msgRef = db.collection("conversations").document(conversationId)
      .collection("messages").document(messageId)

    return try {
      msgRef.update(
        mapOf(
          "deletedForEveryone" to true,
          "updatedAt" to FieldValue.serverTimestamp()
        )
      ).await()
      Result.success(Unit)
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, msgRef.path)
      Result.failure(e)
    }
  }

  suspend fun updateGroupMembers(conversationId: String, newParticipants: List<String>): Result<Unit> {
    val uid = requireUserId()
    val convRef = db.collection("conversations").document(conversationId)

    return try {
      convRef.update(
        mapOf(
          "participantUids" to newParticipants,
          "updatedAt" to FieldValue.serverTimestamp()
        )
      ).await()
      Result.success(Unit)
    } catch (e: Exception) {
      handleFirestoreError(e, OperationType.UPDATE, convRef.path)
      Result.failure(e)
    }
  }
}
