package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import com.example.data.model.Conversation
import com.example.data.model.UserProfile
import com.example.data.repository.ChatRepository
import com.example.data.repository.UserRepository
import com.example.ui.auth.AppLockScreen
import com.example.ui.auth.AuthScreen
import com.example.ui.auth.AuthViewModel
import com.example.ui.auth.ProfileSetupScreen
import com.example.ui.chat.ChatDetailScreen
import com.example.ui.chat.ChatListScreen
import com.example.ui.chat.ChatViewModel
import com.example.ui.chat.CreateGroupDialog
import com.example.ui.chat.GroupInfoDialog
import com.example.ui.chat.JoinGroupDialog
import com.example.ui.chat.NewDirectChatDialog
import com.example.ui.contacts.ContactsScreen
import com.example.ui.profile.ProfileScreen
import com.example.ui.theme.MyApplicationTheme
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth

class MainActivity : ComponentActivity() {

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    setContent {
      MyApplicationTheme {
        FamilyConnectApp()
      }
    }
  }

  override fun onStop() {
    super.onStop()
    // User presence offline update
    Firebase.auth.currentUser?.let {
      // In background, app is backgrounded
    }
  }
}

@Composable
fun FamilyConnectApp() {
  val context = LocalContext.current
  val userRepository = remember { UserRepository(context) }
  val chatRepository = remember { ChatRepository(context) }
  val authViewModel = remember { AuthViewModel(userRepository) }
  val chatViewModel = remember { ChatViewModel(chatRepository, userRepository, context) }

  val currentUser by authViewModel.currentUser.collectAsState()
  val userProfile by authViewModel.userProfile.collectAsState()
  val privateInfo by authViewModel.privateInfo.collectAsState()
  val isSessionUnlocked by authViewModel.isSessionUnlocked.collectAsState()

  // Presence lifecycle
  DisposableEffect(currentUser?.uid) {
    onDispose { }
  }

  // 1. Auth Gate
  if (currentUser == null) {
    AuthScreen(
      viewModel = authViewModel,
      onAuthSuccess = { }
    )
    return
  }

  // 2. Profile Setup Gate (if brand new user with no username yet)
  if (userProfile == null || userProfile?.username.isNullOrBlank()) {
    ProfileSetupScreen(
      viewModel = authViewModel,
      onProfileCreated = { }
    )
    return
  }

  // 3. App Lock PIN Gate
  if (privateInfo?.appLockEnabled == true && !isSessionUnlocked) {
    AppLockScreen(
      viewModel = authViewModel,
      onUnlockSuccess = { }
    )
    return
  }

  // 4. Main Application Interface
  MainAppContent(
    userRepository = userRepository,
    chatViewModel = chatViewModel,
    authViewModel = authViewModel,
    myProfile = userProfile
  )
}

@Composable
fun MainAppContent(
  userRepository: UserRepository,
  chatViewModel: ChatViewModel,
  authViewModel: AuthViewModel,
  myProfile: UserProfile?
) {
  var selectedNavigationTab by remember { mutableIntStateOf(0) } // 0: Chats, 1: Contacts, 2: Profile
  val activeConversation by chatViewModel.activeConversation.collectAsState()
  val participantProfiles by chatViewModel.participantProfiles.collectAsState()

  // Dialog states
  var showNewChatDialog by remember { mutableStateOf(false) }
  var showCreateGroupDialog by remember { mutableStateOf(false) }
  var showJoinGroupDialog by remember { mutableStateOf(false) }
  var showGroupInfoDialog by remember { mutableStateOf(false) }

  // If a conversation is active, show the ChatDetailScreen
  if (activeConversation != null) {
    ChatDetailScreen(
      conversation = activeConversation!!,
      viewModel = chatViewModel,
      onNavigateBack = {
        chatViewModel.clearActiveConversation()
      },
      onOpenGroupInfo = {
        showGroupInfoDialog = true
      }
    )
  } else {
    Scaffold(
      bottomBar = {
        NavigationBar(
          containerColor = MaterialTheme.colorScheme.surface,
          modifier = Modifier
            .navigationBarsPadding()
            .testTag("bottom_nav_bar")
        ) {
          NavigationBarItem(
            selected = selectedNavigationTab == 0,
            onClick = { selectedNavigationTab = 0 },
            icon = { Icon(imageVector = Icons.AutoMirrored.Filled.Chat, contentDescription = "Chats") },
            label = { Text("Chats") },
            modifier = Modifier.testTag("nav_item_chats")
          )
          NavigationBarItem(
            selected = selectedNavigationTab == 1,
            onClick = { selectedNavigationTab = 1 },
            icon = { Icon(imageVector = Icons.Default.People, contentDescription = "Contacts") },
            label = { Text("Contacts") },
            modifier = Modifier.testTag("nav_item_contacts")
          )
          NavigationBarItem(
            selected = selectedNavigationTab == 2,
            onClick = { selectedNavigationTab = 2 },
            icon = { Icon(imageVector = Icons.Default.Person, contentDescription = "Profile") },
            label = { Text("Profile") },
            modifier = Modifier.testTag("nav_item_profile")
          )
        }
      }
    ) { innerPadding ->
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(innerPadding)
      ) {
        when (selectedNavigationTab) {
          0 -> {
            ChatListScreen(
              viewModel = chatViewModel,
              myProfile = myProfile,
              onConversationSelected = { conv ->
                chatViewModel.setActiveConversation(conv)
              },
              onOpenNewChat = { showNewChatDialog = true },
              onOpenCreateGroup = { showCreateGroupDialog = true },
              onOpenJoinGroup = { showJoinGroupDialog = true },
              onOpenProfile = { selectedNavigationTab = 2 }
            )
          }

          1 -> {
            ContactsScreen(
              userRepository = userRepository,
              onStartChatWithUser = { targetUser ->
                chatViewModel.startDirectChat(targetUser) {
                  // Conversation opened
                }
              }
            )
          }

          2 -> {
            ProfileScreen(
              userRepository = userRepository,
              authViewModel = authViewModel,
              onSignedOut = { }
            )
          }
        }
      }
    }
  }

  // Dialogs
  if (showNewChatDialog) {
    NewDirectChatDialog(
      userRepository = userRepository,
      onUserSelected = { targetUser ->
        chatViewModel.startDirectChat(targetUser) {
          showNewChatDialog = false
        }
      },
      onDismiss = { showNewChatDialog = false }
    )
  }

  if (showCreateGroupDialog) {
    CreateGroupDialog(
      onCreateGroup = { name ->
        chatViewModel.createGroup(name, emptyList()) {
          showCreateGroupDialog = false
        }
      },
      onDismiss = { showCreateGroupDialog = false }
    )
  }

  if (showJoinGroupDialog) {
    JoinGroupDialog(
      onJoin = { code ->
        chatViewModel.joinGroupByCode(code) {
          showJoinGroupDialog = false
        }
      },
      onDismiss = { showJoinGroupDialog = false }
    )
  }

  if (showGroupInfoDialog && activeConversation != null) {
    GroupInfoDialog(
      conversation = activeConversation!!,
      participantProfiles = participantProfiles,
      onDismiss = { showGroupInfoDialog = false }
    )
  }
}
