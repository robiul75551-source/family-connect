package com.example.crypto

import android.content.Context
import android.util.Base64
import org.json.JSONObject
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.PublicKey
import java.security.SecureRandom
import java.security.spec.ECGenParameterSpec
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher
import javax.crypto.KeyAgreement
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.SecretKeySpec

object CryptoManager {
  private const val PREFS_NAME = "family_connect_crypto"
  private const val KEY_PRIVATE = "e2ee_private_key"
  private const val KEY_PUBLIC = "e2ee_public_key"
  private const val GCM_IV_LENGTH = 12
  private const val GCM_TAG_LENGTH_BITS = 128

  /**
   * Initializes or loads device ECDH keypair (NIST P-256 curve).
   * Private key never leaves the device.
   */
  fun getOrCreateDeviceKeyPair(context: Context): KeyPair {
    val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    val savedPriv = prefs.getString(KEY_PRIVATE, null)
    val savedPub = prefs.getString(KEY_PUBLIC, null)

    if (savedPriv != null && savedPub != null) {
      try {
        val keyFactory = KeyFactory.getInstance("EC")
        val privBytes = Base64.decode(savedPriv, Base64.NO_WRAP)
        val pubBytes = Base64.decode(savedPub, Base64.NO_WRAP)
        val privateKey = keyFactory.generatePrivate(PKCS8EncodedKeySpec(privBytes))
        val publicKey = keyFactory.generatePublic(X509EncodedKeySpec(pubBytes))
        return KeyPair(publicKey, privateKey)
      } catch (e: Exception) {
        // Fall through to regenerate if corrupted
      }
    }

    val kpg = KeyPairGenerator.getInstance("EC")
    val ecSpec = ECGenParameterSpec("secp256r1")
    kpg.initialize(ecSpec, SecureRandom())
    val keyPair = kpg.generateKeyPair()

    val privBase64 = Base64.encodeToString(keyPair.private.encoded, Base64.NO_WRAP)
    val pubBase64 = Base64.encodeToString(keyPair.public.encoded, Base64.NO_WRAP)

    prefs.edit()
      .putString(KEY_PRIVATE, privBase64)
      .putString(KEY_PUBLIC, pubBase64)
      .apply()

    return keyPair
  }

  fun getDevicePublicKeyBase64(context: Context): String {
    return Base64.encodeToString(getOrCreateDeviceKeyPair(context).public.encoded, Base64.NO_WRAP)
  }

  /**
   * Derives a 256-bit AES shared symmetric key from local private key and remote public key using ECDH + SHA-256.
   */
  fun deriveSharedSecret(localPrivateKey: PrivateKey, peerPublicKeyBase64: String): SecretKey {
    val pubBytes = Base64.decode(peerPublicKeyBase64, Base64.NO_WRAP)
    val keyFactory = KeyFactory.getInstance("EC")
    val peerPublicKey = keyFactory.generatePublic(X509EncodedKeySpec(pubBytes))

    val keyAgreement = KeyAgreement.getInstance("ECDH")
    keyAgreement.init(localPrivateKey)
    keyAgreement.doPhase(peerPublicKey, true)
    val sharedSecret = keyAgreement.generateSecret()

    // Key derivation using SHA-256
    val md = MessageDigest.getInstance("SHA-256")
    val derivedAesKeyBytes = md.digest(sharedSecret)
    return SecretKeySpec(derivedAesKeyBytes, "AES")
  }

  /**
   * Encrypts plaintext string using AES-256-GCM.
   * Returns Pair(ciphertextBase64, ivBase64).
   */
  fun encryptAesGcm(plaintext: String, secretKey: SecretKey): Pair<String, String> {
    val random = SecureRandom()
    val iv = ByteArray(GCM_IV_LENGTH)
    random.nextBytes(iv)

    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.ENCRYPT_MODE, secretKey, GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv))
    val ciphertextBytes = cipher.doFinal(plaintext.toByteArray(Charsets.UTF_8))

    return Pair(
      Base64.encodeToString(ciphertextBytes, Base64.NO_WRAP),
      Base64.encodeToString(iv, Base64.NO_WRAP)
    )
  }

  /**
   * Decrypts ciphertextBase64 using AES-256-GCM and ivBase64.
   */
  fun decryptAesGcm(ciphertextBase64: String, ivBase64: String, secretKey: SecretKey): String {
    val iv = Base64.decode(ivBase64, Base64.NO_WRAP)
    val ciphertextBytes = Base64.decode(ciphertextBase64, Base64.NO_WRAP)

    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.DECRYPT_MODE, secretKey, GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv))
    val decryptedBytes = cipher.doFinal(ciphertextBytes)
    return String(decryptedBytes, Charsets.UTF_8)
  }

  /**
   * Encrypts byte payload (e.g. file, image) with AES-256-GCM.
   */
  fun encryptBytes(data: ByteArray, secretKey: SecretKey): Pair<ByteArray, ByteArray> {
    val random = SecureRandom()
    val iv = ByteArray(GCM_IV_LENGTH)
    random.nextBytes(iv)

    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.ENCRYPT_MODE, secretKey, GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv))
    val encrypted = cipher.doFinal(data)
    return Pair(encrypted, iv)
  }

  fun decryptBytes(encryptedData: ByteArray, iv: ByteArray, secretKey: SecretKey): ByteArray {
    val cipher = Cipher.getInstance("AES/GCM/NoPadding")
    cipher.init(Cipher.DECRYPT_MODE, secretKey, GCMParameterSpec(GCM_TAG_LENGTH_BITS, iv))
    return cipher.doFinal(encryptedData)
  }

  /**
   * Generates a 256-bit random AES key for family group chats.
   */
  fun generateGroupSymmetricKey(): SecretKey {
    val keyBytes = ByteArray(32)
    SecureRandom().nextBytes(keyBytes)
    return SecretKeySpec(keyBytes, "AES")
  }

  /**
   * Builds an encrypted key map for group messages:
   * Wraps the group symmetric key for each participant UID using their shared ECDH key.
   */
  fun buildEncryptedKeyMap(
    groupKey: SecretKey,
    participantsPublicKeys: Map<String, String>, // uid -> peerPublicKeyBase64
    localPrivateKey: PrivateKey
  ): String {
    val json = JSONObject()
    val groupKeyBase64 = Base64.encodeToString(groupKey.encoded, Base64.NO_WRAP)

    for ((uid, pubKeyBase64) in participantsPublicKeys) {
      try {
        val sharedKey = deriveSharedSecret(localPrivateKey, pubKeyBase64)
        val (wrappedKeyBase64, wrappedIv) = encryptAesGcm(groupKeyBase64, sharedKey)
        val entry = JSONObject().apply {
          put("k", wrappedKeyBase64)
          put("iv", wrappedIv)
        }
        json.put(uid, entry)
      } catch (e: Exception) {
        // Skip unresolvable key
      }
    }
    return json.toString()
  }

  /**
   * Unwraps the group symmetric key for the current user from encryptedKeyMap.
   */
  fun unwrapGroupKey(
    encryptedKeyMapJson: String?,
    currentUserId: String,
    senderPublicKeyBase64: String,
    localPrivateKey: PrivateKey
  ): SecretKey? {
    if (encryptedKeyMapJson.isNullOrBlank()) return null
    return try {
      val json = JSONObject(encryptedKeyMapJson)
      if (!json.has(currentUserId)) return null
      val entry = json.getJSONObject(currentUserId)
      val wrappedKeyBase64 = entry.getString("k")
      val wrappedIv = entry.getString("iv")

      val sharedKey = deriveSharedSecret(localPrivateKey, senderPublicKeyBase64)
      val rawGroupKeyBase64 = decryptAesGcm(wrappedKeyBase64, wrappedIv, sharedKey)
      val keyBytes = Base64.decode(rawGroupKeyBase64, Base64.NO_WRAP)
      SecretKeySpec(keyBytes, "AES")
    } catch (e: Exception) {
      null
    }
  }

  /**
   * Hashes App Lock PIN using SHA-256 with 10,000 iterations and salt.
   */
  fun hashPin(pin: String, saltBase64: String): String {
    val salt = Base64.decode(saltBase64, Base64.NO_WRAP)
    val md = MessageDigest.getInstance("SHA-256")
    var current = salt + pin.toByteArray(Charsets.UTF_8)
    for (i in 0 until 10000) {
      current = md.digest(current)
    }
    return Base64.encodeToString(current, Base64.NO_WRAP)
  }

  fun generateSalt(): String {
    val salt = ByteArray(16)
    SecureRandom().nextBytes(salt)
    return Base64.encodeToString(salt, Base64.NO_WRAP)
  }
}
