package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.UserProfile
import com.example.data.repository.ChatRepository
import com.example.data.repository.UserRepository
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class FamilyConnectRepositoryRuleTest : FirestoreEmulatorTestBase() {

  @Test
  fun testUserRegistrationAndProfileCreation() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val email = "alice_${System.currentTimeMillis()}@test.com"
    val uid = signInTestUser(email)

    val userRepo = UserRepository(firestore, context)
    val result = userRepo.registerUserProfile(
      username = "alice_${System.currentTimeMillis() % 10000}",
      displayName = "Alice Doe",
      avatarSeed = "1",
      phone = "+8801712345678",
      email = email
    )

    assertTrue("User registration should succeed", result.isSuccess)

    val profileDoc = firestore.collection("users").document(uid).get()
    assertNotNull(profileDoc)
  }

  @Test
  fun testDirectConversationCreation() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val aliceUid = signInTestUser("alice_${System.currentTimeMillis()}@test.com")

    val chatRepo = ChatRepository(firestore, context)
    val targetUser = UserProfile(
      userId = "bob_mock_${System.currentTimeMillis()}",
      username = "bob_mock",
      displayName = "Bob",
      publicKey = "mockPubKeyBase64"
    )

    val result = chatRepo.getOrCreateDirectConversation(targetUser)
    assertTrue("Direct chat creation should succeed: ${result.exceptionOrNull()?.message}", result.isSuccess)
    val conv = result.getOrNull()
    assertNotNull(conv)
    assertTrue(conv!!.participantUids.contains(aliceUid))
  }

  @Test
  fun testCreateFamilyGroup() = runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val uid = signInTestUser("groupcreator_${System.currentTimeMillis()}@test.com")

    val chatRepo = ChatRepository(firestore, context)
    val result = chatRepo.createFamilyGroup("Khan Family", listOf("member_2", "member_3"))

    assertTrue("Create family group should succeed", result.isSuccess)
    val group = result.getOrNull()
    assertNotNull(group)
    assertEquals("group", group!!.type)
    assertTrue(group.participantUids.contains(uid))
    assertTrue(group.adminUids.contains(uid))
  }
}
