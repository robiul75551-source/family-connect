package com.example

import com.example.ui.auth.BangladeshPhoneUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testBangladeshPhoneNumberFormattingAndValidation() {
    // 1. Valid with leading 0 (017...)
    val (valid1, num1) = BangladeshPhoneUtils.formatAndValidate("01712345678")
    assertTrue("01712345678 should be valid", valid1)
    assertEquals("+8801712345678", num1)

    // 2. Valid with 10 digits without leading 0 (181...)
    val (valid2, num2) = BangladeshPhoneUtils.formatAndValidate("1812345678")
    assertTrue("1812345678 should be valid", valid2)
    assertEquals("+8801812345678", num2)

    // 3. Valid with +880 already
    val (valid3, num3) = BangladeshPhoneUtils.formatAndValidate("+8801912345678")
    assertTrue("+8801912345678 should be valid", valid3)
    assertEquals("+8801912345678", num3)

    // 4. Valid with spaces and dashes
    val (valid4, num4) = BangladeshPhoneUtils.formatAndValidate("+880 1712-345678")
    assertTrue("+880 1712-345678 should be valid", valid4)
    assertEquals("+8801712345678", num4)

    // 5. Test other BD mobile operator prefixes: 013, 014, 015, 016
    val (validGpNew, _) = BangladeshPhoneUtils.formatAndValidate("01312345678")
    assertTrue("013 operator should be valid", validGpNew)

    val (validBlNew, _) = BangladeshPhoneUtils.formatAndValidate("01412345678")
    assertTrue("014 operator should be valid", validBlNew)

    val (validTeletalk, _) = BangladeshPhoneUtils.formatAndValidate("01512345678")
    assertTrue("015 operator should be valid", validTeletalk)

    val (validAirtel, _) = BangladeshPhoneUtils.formatAndValidate("01612345678")
    assertTrue("016 operator should be valid", validAirtel)

    // 6. Invalid numbers
    val (invalidShort, _) = BangladeshPhoneUtils.formatAndValidate("017123")
    assertFalse("Short number should be invalid", invalidShort)

    val (invalidLandline, _) = BangladeshPhoneUtils.formatAndValidate("029876543")
    assertFalse("Landline should be invalid", invalidLandline)

    val (invalidEmpty, _) = BangladeshPhoneUtils.formatAndValidate("")
    assertFalse("Empty should be invalid", invalidEmpty)
  }
}

