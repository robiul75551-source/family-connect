const { initializeTestEnvironment, assertFails, assertSucceeds } = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

const PROJECT_ID = "demo-no-project";
const DATABASE_ID = "ai-studio-android-familyco-62e7d7c7-b636-469e-b95e-59294288c0ac";

let testEnv;

before(async () => {
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules: fs.readFileSync("firestore.rules", "utf8"),
      host: "127.0.0.1",
      port: 8085
    }
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user cannot read or write user profiles", async () => {
  const unauthedDb = testEnv.unauthenticatedContext().firestore(DATABASE_ID);
  const docRef = unauthedDb.collection("users").doc("user_1");
  await assertFails(docRef.get());
  await assertFails(docRef.set({ username: "alice", displayName: "Alice" }));
});

test("Authenticated user can create their own public profile", async () => {
  const aliceDb = testEnv.authenticatedContext("alice_uid").firestore(DATABASE_ID);
  const docRef = aliceDb.collection("users").doc("alice_uid");
  await assertSucceeds(docRef.set({
    userId: "alice_uid",
    username: "alice",
    displayName: "Alice Family",
    createdAt: new Date(),
    isOnline: true
  }));
});

test("User cannot create another user's public profile", async () => {
  const aliceDb = testEnv.authenticatedContext("alice_uid").firestore(DATABASE_ID);
  const docRef = aliceDb.collection("users").doc("bob_uid");
  await assertFails(docRef.set({
    userId: "bob_uid",
    username: "bob",
    displayName: "Bob Family",
    createdAt: new Date()
  }));
});

test("User can read another user's public profile but not private info", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    const adminDb = context.firestore(DATABASE_ID);
    await adminDb.collection("users").doc("bob_uid").set({
      userId: "bob_uid",
      username: "bob",
      displayName: "Bob Family",
      createdAt: new Date()
    });
    await adminDb.collection("users").doc("bob_uid").collection("private").doc("info").set({
      userId: "bob_uid",
      phone: "+8801700000000",
      email: "bob@example.com",
      updatedAt: new Date()
    });
  });

  const aliceDb = testEnv.authenticatedContext("alice_uid").firestore(DATABASE_ID);
  await assertSucceeds(aliceDb.collection("users").doc("bob_uid").get());
  await assertFails(aliceDb.collection("users").doc("bob_uid").collection("private").doc("info").get());
});

test("Only conversation participants can read messages", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    const adminDb = context.firestore(DATABASE_ID);
    await adminDb.collection("conversations").doc("conv_1").set({
      conversationId: "conv_1",
      type: "direct",
      participantUids: ["alice_uid", "bob_uid"],
      createdAt: new Date()
    });
    await adminDb.collection("conversations").doc("conv_1").collection("messages").doc("msg_1").set({
      messageId: "msg_1",
      conversationId: "conv_1",
      senderId: "alice_uid",
      participantUids: ["alice_uid", "bob_uid"],
      ciphertext: "enc_hello_world",
      iv: "random_iv_123",
      messageType: "text",
      createdAt: new Date()
    });
  });

  const bobDb = testEnv.authenticatedContext("bob_uid").firestore(DATABASE_ID);
  await assertSucceeds(bobDb.collection("conversations").doc("conv_1").get());
  await assertSucceeds(bobDb.collection("conversations").doc("conv_1").collection("messages").doc("msg_1").get());

  const charlieDb = testEnv.authenticatedContext("charlie_uid").firestore(DATABASE_ID);
  await assertFails(charlieDb.collection("conversations").doc("conv_1").get());
  await assertFails(charlieDb.collection("conversations").doc("conv_1").collection("messages").doc("msg_1").get());
});

test("Sender can post encrypted message to conversation", async () => {
  await testEnv.withSecurityRulesDisabled(async (context) => {
    const adminDb = context.firestore(DATABASE_ID);
    await adminDb.collection("conversations").doc("conv_1").set({
      conversationId: "conv_1",
      type: "direct",
      participantUids: ["alice_uid", "bob_uid"],
      createdAt: new Date()
    });
  });

  const aliceDb = testEnv.authenticatedContext("alice_uid").firestore(DATABASE_ID);
  const msgRef = aliceDb.collection("conversations").doc("conv_1").collection("messages").doc("msg_2");
  await assertSucceeds(msgRef.set({
    messageId: "msg_2",
    conversationId: "conv_1",
    senderId: "alice_uid",
    participantUids: ["alice_uid", "bob_uid"],
    ciphertext: "encrypted_secret_data",
    iv: "iv_string",
    messageType: "text",
    createdAt: new Date()
  }));
});
